// lib/registrar_pedido.dart
import 'package:flutter/material.dart';
import 'producto.dart';
import 'pedido.dart';
import 'detalle_pedido.dart';
import 'database.dart';
import 'formato.dart';

class RegistrarPedidoPage extends StatefulWidget {
  final Pedido? pedidoEditar;
  final int tandaId;

  const RegistrarPedidoPage({
    super.key,
    required this.tandaId,
    this.pedidoEditar,
  });

  @override
  State<RegistrarPedidoPage> createState() => _RegistrarPedidoPageState();
}

class _RegistrarPedidoPageState extends State<RegistrarPedidoPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController clienteController = TextEditingController();
  final TextEditingController direccionController = TextEditingController();
  final TextEditingController pagoParcialController = TextEditingController();
  final TextEditingController searchController = TextEditingController();

  List<Map<String, dynamic>> productos = [];
  List<Map<String, dynamic>> productosFiltrados = [];
  List<DetallePedido> detalles = [];
  bool entregado = false;
  bool pagado = false;

  Map<int, int> _stockDisponible = {};
  Map<int, int> _cantidadesEnPedido = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    searchController.addListener(filtrarProductos);
    _loadData();
  }

  @override
  void dispose() {
    clienteController.dispose();
    direccionController.dispose();
    pagoParcialController.dispose();
    searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final productosDeTanda = await AppDatabase.obtenerProductosDeTanda(widget.tandaId);

    if (mounted) {
      setState(() {
        productos = productosDeTanda.map((map) {
          final productoId = map['productoId'] as int;
          final stockTotal = map['stock'] as int;
          _stockDisponible[productoId] = stockTotal;
          return {
            'producto': Producto(
              id: productoId,
              nombre: map['nombre'] as String,
              precio: map['precio'] as double,
            ),
            'stock': stockTotal,
          };
        }).toList();
        productosFiltrados = List.from(productos);
        _isLoading = false;
      });
    }

    if (widget.pedidoEditar != null) {
      final pedido = widget.pedidoEditar!;
      clienteController.text = pedido.cliente;
      direccionController.text = pedido.direccion;
      pagoParcialController.text = pedido.pagoParcial.toStringAsFixed(0);
      entregado = pedido.entregado;
      pagado = pedido.pagado;
      detalles = List.from(pedido.detalles);
      
      for (var detalle in pedido.detalles) {
        _cantidadesEnPedido[detalle.producto.id!] = detalle.cantidad;
        _stockDisponible[detalle.producto.id!] = (_stockDisponible[detalle.producto.id!] ?? 0) + detalle.cantidad;
      }
    }
  }

  void filtrarProductos() {
    final query = searchController.text.toLowerCase();
    setState(() {
      productosFiltrados = productos
          .where((p) => (p['producto'] as Producto).nombre.toLowerCase().contains(query))
          .toList();
    });
  }

  void agregarDetalle(Producto producto, int cantidad) {
    setState(() {
      final productoId = producto.id!;
      final cantidadActualEnPedido = _cantidadesEnPedido[productoId] ?? 0;
      final nuevaCantidadTotalEnPedido = cantidadActualEnPedido + cantidad;
      
      final stockInicial = _stockDisponible[productoId] ?? 0;
      final stockRestante = stockInicial - cantidadActualEnPedido;

      if (cantidad > stockRestante) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('No hay suficiente stock de ${producto.nombre}. Disponibles: $stockRestante'),
          ),
        );
        return;
      }
      
      _cantidadesEnPedido[productoId] = nuevaCantidadTotalEnPedido;

      final index = detalles.indexWhere((d) => d.producto.id == productoId);
      if (index != -1) {
        detalles[index].cantidad = nuevaCantidadTotalEnPedido;
      } else {
        detalles.add(DetallePedido(producto: producto, cantidad: nuevaCantidadTotalEnPedido));
      }
    });
  }

  void quitarDetalle(DetallePedido detalle) {
    setState(() {
      final productoId = detalle.producto.id!;
      _cantidadesEnPedido.remove(productoId);
      detalles.remove(detalle);
    });
  }

  double get totalPedido => detalles.fold(0, (suma, det) => suma + det.subtotal);

  Future<void> guardarPedido() async {
    if (!_formKey.currentState!.validate()) return;
    if (detalles.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Agrega al menos un producto al pedido')),
      );
      return;
    }
    final pago = pagado ? totalPedido : (double.tryParse(pagoParcialController.text) ?? 0.0);
    final pedido = Pedido(
      id: widget.pedidoEditar?.id,
      tandaId: widget.tandaId,
      cliente: clienteController.text,
      direccion: direccionController.text,
      entregado: entregado,
      pagado: pagado,
      pagoParcial: pago,
      detalles: detalles,
    );
    if (widget.pedidoEditar != null) {
      await AppDatabase.actualizarPedidoConDetalles(pedido);
    } else {
      await AppDatabase.insertarPedidoConDetalles(pedido);
    }
    if (mounted) Navigator.pop(context, true);
  }

  void mostrarDialogoCantidad(Producto producto) {
    final cantidadController = TextEditingController(text: '1');
    final stockInicial = _stockDisponible[producto.id!] ?? 0;
    final cantidadEnPedido = _cantidadesEnPedido[producto.id!] ?? 0;
    final stockDisponible = stockInicial - cantidadEnPedido;
    
    if (stockDisponible <= 0) return;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Cantidad para ${producto.nombre}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: cantidadController,
              keyboardType: TextInputType.number,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Cantidad'),
            ),
            const SizedBox(height: 8),
            Text(
              'Stock disponible: $stockDisponible',
              style: TextStyle(
                color: stockDisponible > 0 ? Colors.green.shade700 : Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(child: const Text('Cancelar'), onPressed: () => Navigator.pop(context)),
          ElevatedButton(
            child: const Text('Agregar'),
            onPressed: () {
              final cantidad = int.tryParse(cantidadController.text) ?? 0;
              if (cantidad <= 0) {
                 ScaffoldMessenger.of(context).showSnackBar(
                   const SnackBar(content: Text('La cantidad debe ser mayor a 0')),
                 );
                 return;
              }
              if (cantidad > stockDisponible) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Cantidad no disponible. Solo quedan $stockDisponible')),
                );
              } else {
                agregarDetalle(producto, cantidad);
                Navigator.pop(context);
              }
            },
          ),
        ],
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Cargando...')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.pedidoEditar != null ? 'Editar Pedido' : 'Nuevo Pedido'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save_outlined),
            onPressed: guardarPedido,
            tooltip: 'Guardar Pedido',
          )
        ],
      ),
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            Text('Total del Pedido', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey[600])),
            Text(totalPedido.aPesos(), style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 24),

            Text('Datos del Cliente', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            TextFormField(
              controller: clienteController,
              decoration: const InputDecoration(labelText: 'Nombre del Cliente', prefixIcon: Icon(Icons.person_outline)),
              validator: (v) => v!.isEmpty ? 'Ingresa el nombre del cliente' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: direccionController,
              decoration: const InputDecoration(labelText: 'Dirección', prefixIcon: Icon(Icons.location_on_outlined)),
              validator: (v) => v!.isEmpty ? 'Ingresa la dirección' : null,
            ),
            const SizedBox(height: 24),
            
            Text('Estado y Pago', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: Column(
                  children: [
                      Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: TextFormField(
                          controller: pagoParcialController,
                          keyboardType: TextInputType.number,
                          enabled: !pagado,
                          decoration: InputDecoration(
                            labelText: 'Abono Parcial',
                            prefixIcon: const Icon(Icons.attach_money_outlined),
                            fillColor: Theme.of(context).colorScheme.background,
                          ),
                          ),
                      ),
                      SwitchListTile(
                        title: const Text('Pagado Completamente'),
                        value: pagado,
                        onChanged: (value) => setState(() {
                          pagado = value;
                          if (pagado) {
                            pagoParcialController.text = totalPedido.toStringAsFixed(0);
                          }
                        }),
                      ),
                      SwitchListTile(
                        title: const Text('Entregado'),
                        value: entregado,
                        onChanged: (value) => setState(() => entregado = value),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            Text('Añadir Productos', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            TextField(controller: searchController, decoration: const InputDecoration(labelText: 'Buscar producto...', prefixIcon: Icon(Icons.search))),
            const SizedBox(height: 12),
            SizedBox(
              height: 140,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: productosFiltrados.length,
                itemBuilder: (context, index) {
                  final pMap = productosFiltrados[index];
                  final p = pMap['producto'] as Producto;
                  final stockDisponible = (_stockDisponible[p.id!] ?? 0) - (_cantidadesEnPedido[p.id!] ?? 0);
                  final isStockAvailable = stockDisponible > 0;

                  return Card(
                    child: InkWell(
                      onTap: isStockAvailable ? () => mostrarDialogoCantidad(p) : null,
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        width: 130,
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(p.nombre, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text(p.precio.aPesos()),
                            const SizedBox(height: 4),
                            Text(
                              'Stock: $stockDisponible',
                              style: TextStyle(
                                color: isStockAvailable ? Colors.green.shade700 : Colors.red.shade700,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Icon(Icons.add_shopping_cart_outlined, color: isStockAvailable ? Theme.of(context).colorScheme.primary : Colors.grey),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),
            
            Text('Resumen del Pedido', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            detalles.isEmpty
                ? const Text('Aún no has agregado productos.', style: TextStyle(color: Colors.grey))
                : Card(
                    child: ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: detalles.length,
                      itemBuilder: (_, index) {
                        final detalle = detalles[index];
                        return ListTile(
                          leading: const Icon(Icons.shopping_basket_outlined),
                          title: Text('${detalle.cantidad}x ${detalle.producto.nombre}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(detalle.subtotal.aPesos(), style: const TextStyle(fontWeight: FontWeight.bold)),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.red),
                                onPressed: () => quitarDetalle(detalle),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}