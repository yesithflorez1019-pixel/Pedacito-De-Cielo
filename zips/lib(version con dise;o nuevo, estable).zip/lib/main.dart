import 'package:flutter/material.dart';
import 'package:postres_app/inventario_page.dart';
import 'ver_productos.dart';
import 'control_tandas.dart';
import 'informe_no_pagados.dart';
import 'finanzas/home_finanzas.dart';
import 'reportes_page.dart';

void main() {
  runApp(const PedacitoDeCielo());
}

class PedacitoDeCielo extends StatelessWidget {
  const PedacitoDeCielo({super.key});

  @override
  Widget build(BuildContext context) {
    const Color colorPrimario = Color(0xFFE91E63);
    const Color colorAcento = Color(0xFFFFC107);
    const Color colorFondoOscuro = Color(0xFF1C1A3A); // Nuevo color de fondo
    const Color colorSuperficieOscura = Color(0xFF2C2A4F); // Nuevo color de superficie

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pedacito de Cielo',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: colorPrimario,
          primary: colorPrimario,
          secondary: colorAcento,
          background: colorFondoOscuro, // Usamos el nuevo color de fondo
          surface: colorSuperficieOscura, // Usamos el nuevo color de superficie
          brightness: Brightness.dark, // Cambiamos el brillo a oscuro
        ),
        textTheme: const TextTheme(
          headlineMedium: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 24),
          titleLarge: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 18),
          bodyMedium: TextStyle(fontSize: 16.0, color: Colors.white),
          labelLarge: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0, color: Colors.white),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: colorFondoOscuro,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          clipBehavior: Clip.antiAlias,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: colorPrimario,
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: colorPrimario,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
            textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: colorSuperficieOscura,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: colorPrimario, width: 2.0),
          ),
        ),
        dialogTheme: DialogThemeData(
          backgroundColor: colorSuperficieOscura,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final options = <_MenuOption>[
      _MenuOption(
        icon: Icons.cake_outlined,
        label: 'Productos',
        color: Colors.pinkAccent,
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const VerProductosPage())),
      ),
      _MenuOption(
        icon: Icons.list_alt_outlined,
        label: 'Tandas y Pedidos',
        color: Colors.blueAccent,
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ControlTandasPage())),
      ),
      _MenuOption(
        icon: Icons.payment_outlined,
        label: 'Informe de Deudas',
        color: Colors.orangeAccent,
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const InformeNoPagadosPage())),
      ),
      _MenuOption(
        icon: Icons.inventory_2_outlined,
        label: 'Inventario',
        color: Colors.purpleAccent,
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const InventarioPage())),
      ),
      _MenuOption(
        icon: Icons.attach_money,
        label: 'Finanzas Personales',
        color: Colors.greenAccent,
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const HomeFinanzasPage())),
      ),
      _MenuOption(
        icon: Icons.bar_chart,
        label: 'Panel de Reportes',
        color: Colors.tealAccent,
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ReportesPage())),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pedacito de Cielo'),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          childAspectRatio: 1,
        ),
        itemCount: options.length,
        itemBuilder: (context, index) {
          final opt = options[index];
          return Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: Theme.of(context).colorScheme.surface,
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => opt.onTap(context),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: opt.color.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(opt.icon, size: 40, color: opt.color),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      opt.label,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _MenuOption {
  final IconData icon;
  final String label;
  final Color color;
  final void Function(BuildContext) onTap;
  _MenuOption({required this.icon, required this.label, required this.onTap, required this.color});
}