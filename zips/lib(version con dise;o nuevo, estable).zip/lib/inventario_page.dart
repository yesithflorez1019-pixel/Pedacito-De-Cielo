// lib/inventario_page.dart
import 'package:flutter/material.dart';
import 'insumos_page.dart'; // Importa tu nueva página de insumos
import 'ver_productos.dart';
 // La vista de productos que ya tenías

class InventarioPage extends StatelessWidget {
  const InventarioPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Centro de Inventario"),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.blender_outlined), text: 'Insumos'),
              Tab(icon: Icon(Icons.cake_outlined), text: 'Productos'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [

            InsumosPage(),


            VerProductosPage(esSubPagina: true),
          ],
        ),
      ),
    );
  }
}


