// lib/ver_productos.dart
import 'package:flutter/material.dart';
import 'producto.dart';
import 'database.dart';
import 'agregar_producto.dart';
import 'formato.dart';
import 'producto_detalle_page.dart';

class VerProductosPage extends StatefulWidget {
  final bool esSubPagina;

  const VerProductosPage({super.key, this.esSubPagina = false});

  @override
  State<VerProductosPage> createState() => _VerProductosPageState();
}

class _VerProductosPageState extends State<VerProductosPage> {
  List<Map<String, dynamic>> productosConCosto = [];

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    productosConCosto = await AppDatabase.obtenerProductosConCosto();
    if (mounted) setState(() {});
  }

  // --- FUNCIÓN CORREGIDA ---
  void navegarADetalle(Producto p) async {
    // Navigator.push ahora devuelve 'true' si hubo cambios en la página de detalle
    final bool? huboCambios = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => ProductoDetallePage(producto: p)),
    );

    // Solo recargamos la lista si la página anterior nos avisó que hubo un cambio.
    if (huboCambios == true) {
      await cargar();
    }
  }
  
  void agregar() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AgregarProductoPage()),
    );
    await cargar();
  }
  
  Future<void> eliminar(int id) async {
    // Tu lógica de eliminación aquí
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.esSubPagina ? null : AppBar(title: const Text('Rentabilidad de Productos')),
      backgroundColor: Theme.of(context).colorScheme.background,
      floatingActionButton: widget.esSubPagina
          ? null
          : FloatingActionButton(
              onPressed: agregar,
              child: const Icon(Icons.add),
            ),
      body: productosConCosto.isEmpty
          ? _buildEmptyState()
          : RefreshIndicator(
              onRefresh: cargar,
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 8, bottom: 80),
                itemCount: productosConCosto.length,
                itemBuilder: (_, i) {
                  final data = productosConCosto[i];
                  final producto = Producto.fromMap(data);
                  final costo = (data['costo'] as num?)?.toDouble() ?? 0.0;
                  final ganancia = producto.precio - costo;

                  return Card(
                    child: ListTile(
                      onTap: () => navegarADetalle(producto),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      leading: CircleAvatar(
                        backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                        child: Icon(Icons.cake_outlined, color: Theme.of(context).colorScheme.primary),
                      ),
                      title: Text(producto.nombre, style: Theme.of(context).textTheme.titleLarge),
                      subtitle: _buildDetallesFinancieros(producto.precio, costo, ganancia),
                      trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Colors.grey),
                    ),
                  );
                },
              ),
            ),
    );
  }

  Widget _buildDetallesFinancieros(double precio, double costo, double ganancia) {
    return Padding(
      padding: const EdgeInsets.only(top: 4.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoRow('Venta:', precio.aPesos(), Colors.blue.shade700),
          _buildInfoRow('Costo:', costo.aPesos(), Colors.orange.shade800),
          _buildInfoRow('Ganancia:', ganancia.aPesos(), Colors.green.shade800, isBold: true),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, Color color, {bool isBold = false}) {
    return Text.rich(
      TextSpan(
        text: label,
        style: const TextStyle(fontSize: 14),
        children: [
          TextSpan(
            text: ' $value',
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
     return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.cake_outlined, size: 80, color: Colors.grey[300]),
            const SizedBox(height: 16),
            Text(
              'Aún no tienes productos',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text(
              'Toca el botón + para agregar el primero.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[600], fontSize: 16),
            ),
          ],
        ),
      );
  }
}