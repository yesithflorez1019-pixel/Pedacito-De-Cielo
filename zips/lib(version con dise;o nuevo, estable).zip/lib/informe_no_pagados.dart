// lib/informe_no_pagados.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'database.dart';
import 'registrar_pedido.dart';

class InformeNoPagadosPage extends StatefulWidget {
  const InformeNoPagadosPage({super.key});

  @override
  State<InformeNoPagadosPage> createState() => _InformeNoPagadosPageState();
}

class _InformeNoPagadosPageState extends State<InformeNoPagadosPage> {
  List<Map<String, dynamic>> clientes = [];
  List<Map<String, dynamic>> clientesFiltrados = [];
  double _deudaTotalGeneral = 0.0;
  final searchController = TextEditingController();

  final formatoPesos = NumberFormat.currency(
    locale: 'es_CO', // Usamos el local de Colombia
    symbol: '\$',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    searchController.addListener(_filtrarClientes);
    _cargarClientes();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _cargarClientes() async {
    final data = await AppDatabase.obtenerClientesDeudores();
    double deudaGeneral = 0;

    final clientesConDeuda = <Map<String, dynamic>>[];
    for (var clienteNombre in data) {
      final pedidos = await AppDatabase.obtenerPedidosNoPagadosPorCliente(clienteNombre);
      final deudaCliente = pedidos.fold<double>(0.0, (sum, p) => sum + p.totalPendiente);
      
      if (deudaCliente > 0) {
        clientesConDeuda.add({'cliente': clienteNombre, 'deuda': deudaCliente});
        deudaGeneral += deudaCliente;
      }
    }
    
    if (!mounted) return;
    setState(() {
      clientes = clientesConDeuda..sort((a,b) => (b['deuda'] as double).compareTo(a['deuda']));
      clientesFiltrados = List.from(clientes);
      _deudaTotalGeneral = deudaGeneral;
    });
  }

  void _filtrarClientes() {
    final query = searchController.text.toLowerCase();
    setState(() {
      clientesFiltrados = clientes
          .where((c) => (c['cliente'] as String).toLowerCase().contains(query))
          .toList();
    });
  }

  Future<void> _liquidarCliente(String cliente) async {
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Confirmar Liquidación"),
        content: Text("¿Estás seguro de marcar todos los pedidos de $cliente como pagados?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Cancelar")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Sí, liquidar"),
          ),
        ],
      ),
    );

    if (confirmado == true) {
      await AppDatabase.liquidarCliente(cliente);
      await _cargarClientes();
    }
  }

  Future<List<Map<String, dynamic>>> _obtenerPedidosCliente(String cliente) async {
    final pedidos = await AppDatabase.obtenerPedidosNoPagadosPorCliente(cliente);
    return Future.wait(pedidos.map((p) async {
      String nombreTanda = '';
      if (p.tandaId != 0) {
        final tanda = await AppDatabase.obtenerTandasConConteo();
        final match = tanda.firstWhere((t) => t['id'] == p.tandaId, orElse: () => {'nombre': 'Desconocida'});
        nombreTanda = match['nombre'] as String;
      }
      return {
        'objetoPedido': p,
        'tandaId': p.tandaId,
        'tanda': nombreTanda,
        'pendiente': p.totalPendiente,
        'detalles': p.detalles.map((d) => {'producto': d.producto.nombre, 'cantidad': d.cantidad, 'subtotal': d.subtotal}).toList(),
      };
    }).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Informe de Deudas"),
         actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _cargarClientes,
            )
          ],
      ),
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: TextField(
              controller: searchController,
              decoration: const InputDecoration(labelText: 'Buscar cliente', prefixIcon: Icon(Icons.search)),
            ),
          ),
          _buildResumenGeneral(),
          Expanded(
            child: clientesFiltrados.isEmpty
                ? _buildEmptyState()
                : RefreshIndicator(
                    onRefresh: _cargarClientes,
                    child: ListView.builder(
                      padding: const EdgeInsets.only(top: 8, bottom: 20),
                      itemCount: clientesFiltrados.length,
                      itemBuilder: (context, i) {
                        final clienteData = clientesFiltrados[i];
                        return _buildClienteCard(clienteData);
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildResumenGeneral() {
    return Card(
      color: Colors.red.shade50,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.red.shade200),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red.shade700),
            const SizedBox(width: 12),
            const Expanded(child: Text("Deuda Total Pendiente", style: TextStyle(fontWeight: FontWeight.bold))),
            Text(
              formatoPesos.format(_deudaTotalGeneral),
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.red.shade900),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.check_circle_outline_rounded, size: 80, color: Colors.green[300]),
          const SizedBox(height: 16),
          Text('¡Felicidades!', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.grey)),
          const SizedBox(height: 8),
          Text('No hay clientes con deudas pendientes. 🎉', style: TextStyle(color: Colors.grey[600], fontSize: 16)),
        ],
      ),
    );
  }

  Widget _buildClienteCard(Map<String, dynamic> clienteData) {
    final cliente = clienteData['cliente'] as String;
    final deuda = clienteData['deuda'] as double;
    return Card(
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          child: Text(
            cliente.substring(0, 1).toUpperCase(),
            style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold),
          ),
        ),
        title: Text(cliente, style: Theme.of(context).textTheme.titleLarge),
        subtitle: Text("Deuda total: ${formatoPesos.format(deuda)}", style: const TextStyle(color: Colors.red)),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _obtenerPedidosCliente(cliente),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Padding(padding: EdgeInsets.all(16), child: Text("No se encontraron pedidos pendientes."));
                }
                final pedidos = snapshot.data!;
                return Column(
                  children: [
                    ...pedidos.map((pedido) => _buildPedidoItem(pedido)).toList(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.check_circle_outline, size: 18),
                        label: const Text("Liquidar Deuda del Cliente"),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () => _liquidarCliente(cliente),
                      ),
                    )
                  ],
                );
              },
            ),
          )
        ],
      ),
    );
  }

  Widget _buildPedidoItem(Map<String, dynamic> pedido) {
    final detalles = pedido['detalles'] as List<Map<String, dynamic>>;
    return ListTile(
      title: Text(
        "Tanda: ${pedido['tanda']}",
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Pendiente: ${formatoPesos.format(pedido['pendiente'])}"),
          ...detalles.map((d) => Text("• ${d['cantidad']}x ${d['producto']}", style: const TextStyle(color: Colors.grey))),
        ],
      ),
      trailing: IconButton(
        icon: const Icon(Icons.edit_outlined, color: Colors.blue),
        tooltip: "Editar Pedido",
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => RegistrarPedidoPage(
                pedidoEditar: pedido['objetoPedido'],
                tandaId: pedido['tandaId'],
              ),
            ),
          );
          await _cargarClientes();
        },
      ),
      isThreeLine: true,
    );
  }
}