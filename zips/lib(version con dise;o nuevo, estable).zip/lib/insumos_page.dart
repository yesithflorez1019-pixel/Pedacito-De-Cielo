// lib/insumos_page.dart
import 'package:flutter/material.dart';
import 'database.dart';
import 'insumo.dart';
import 'formato.dart';

class InsumosPage extends StatefulWidget {
  const InsumosPage({super.key});

  @override
  State<InsumosPage> createState() => _InsumosPageState();
}

class _InsumosPageState extends State<InsumosPage> {
  List<Insumo> _insumos = [];

  @override
  void initState() {
    super.initState();
    _cargarInsumos();
  }

  Future<void> _cargarInsumos() async {
    final data = await AppDatabase.getInsumos();
    setState(() {
      _insumos = data;
    });
  }

  // --- DIÁLOGO MEJORADO CON CALCULADORA DE COSTOS ---
  Future<void> _mostrarDialogoInsumo({Insumo? insumo}) async {
    final esNuevo = insumo == null;
    final nombreCtrl = TextEditingController(text: insumo?.nombre ?? '');
    
    // Controladores para la calculadora
    final precioTotalCtrl = TextEditingController();
    final cantidadCompradaCtrl = TextEditingController();
    
    String unidadSeleccionada = insumo?.unidad ?? 'g';
    double costoCalculado = insumo?.precio ?? 0.0;

    // Si estamos editando, mostramos el costo por unidad actual
    final precioUnitarioCtrl = TextEditingController(text: insumo?.precio.toString() ?? '');


    final guardado = await showDialog<bool>(
      context: context,
      builder: (context) {
        // StatefulBuilder es necesario para que la UI del diálogo se actualice
        return StatefulBuilder(
          builder: (context, setDialogState) {

            void calcularCosto() {
              final precioTotal = double.tryParse(precioTotalCtrl.text) ?? 0.0;
              final cantidadTotal = double.tryParse(cantidadCompradaCtrl.text) ?? 0.0;
              if (cantidadTotal > 0) {
                setDialogState(() {
                  costoCalculado = precioTotal / cantidadTotal;
                  precioUnitarioCtrl.text = costoCalculado.toStringAsFixed(2);
                });
              }
            }

            return AlertDialog(
              title: Text(esNuevo ? 'Nuevo Insumo' : 'Actualizar Costo'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: nombreCtrl,
                      decoration: const InputDecoration(labelText: 'Nombre del Insumo'),
                    ),
                    const SizedBox(height: 16),
                    Text('Calcular Costo por Unidad (Opcional)', style: Theme.of(context).textTheme.titleSmall),
                    const Divider(),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: precioTotalCtrl,
                            onChanged: (_) => calcularCosto(),
                            decoration: const InputDecoration(labelText: 'Precio del Paquete', prefixText: '\$ '),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: TextField(
                            controller: cantidadCompradaCtrl,
                            onChanged: (_) => calcularCosto(),
                            decoration: const InputDecoration(labelText: 'Cantidad'),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text('Unidad de Medida', style: Theme.of(context).textTheme.bodySmall),
                    DropdownButton<String>(
                      value: unidadSeleccionada,
                      isExpanded: true,
                      items: const [
                        DropdownMenuItem(value: 'g', child: Text('Gramos (g)')),
                        DropdownMenuItem(value: 'ml', child: Text('Mililitros (ml)')),
                        DropdownMenuItem(value: 'unidad', child: Text('Unidad (u)')),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() => unidadSeleccionada = value);
                        }
                      },
                    ),
                    const Divider(),
                    TextField(
                      controller: precioUnitarioCtrl,
                      decoration: InputDecoration(
                        labelText: 'Costo Final por Unidad (\$ / ${unidadSeleccionada})',
                        filled: true,
                        fillColor: Colors.grey.shade200,
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
                ElevatedButton(
                  onPressed: () async {
                    final nombre = nombreCtrl.text.trim();
                    final precioFinal = double.tryParse(precioUnitarioCtrl.text) ?? 0.0;
                    
                    if (nombre.isNotEmpty && precioFinal > 0) {
                      final nuevoInsumo = Insumo(
                        id: insumo?.id,
                        nombre: nombre,
                        precio: precioFinal,
                        unidad: unidadSeleccionada,
                      );
                      if (esNuevo) {
                        await AppDatabase.insertarInsumo(nuevoInsumo);
                      } else {
                        // TODO: Crear AppDatabase.actualizarInsumo(nuevoInsumo);
                      }
                      Navigator.pop(context, true);
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );

    if (guardado == true) {
      _cargarInsumos();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _mostrarDialogoInsumo(),
        label: const Text('Nuevo Insumo'),
        icon: const Icon(Icons.add),
      ),
      body: _insumos.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.inventory_2_outlined, size: 80, color: Colors.grey[300]),
                  const SizedBox(height: 16),
                  Text('No hay insumos', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.grey)),
                  const SizedBox(height: 8),
                  Text('Agrega tu materia prima aquí.', style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.only(top: 8, bottom: 90),
              itemCount: _insumos.length,
              itemBuilder: (context, index) {
                final insumo = _insumos[index];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                      child: const Icon(Icons.blender_outlined),
                    ),
                    title: Text(insumo.nombre, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('Costo: ${insumo.precio.aPesos()} / ${insumo.unidad}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.edit_outlined, color: Colors.blue),
                      onPressed: () => _mostrarDialogoInsumo(insumo: insumo),
                    ),
                  ),
                );
              },
            ),
    );
  }
}