// lib/informe_ingresos.dart
import 'package:flutter/material.dart';
import 'database.dart';
import 'gasto.dart';
import 'formato.dart';
import 'package:intl/intl.dart';

class InformeIngresosPage extends StatefulWidget {
  final int tandaId;
  final String nombreTanda;
  const InformeIngresosPage({
    super.key,
    required this.tandaId,
    required this.nombreTanda,
  });

  @override
  State<InformeIngresosPage> createState() => _InformeIngresosPageState();
}

class _InformeIngresosPageState extends State<InformeIngresosPage> {
  List<Map<String, dynamic>> ingresos = [];
  List<Gasto> gastos = [];
  double totalPagado = 0.0;
  double totalGastos = 0.0;

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    ingresos = await AppDatabase.obtenerIngresosPorProducto(widget.tandaId);
    totalPagado = await AppDatabase.obtenerTotalPagosParcialesPorTanda(widget.tandaId);
    gastos = await AppDatabase.obtenerGastosPorTanda(widget.tandaId);
    totalGastos = await AppDatabase.obtenerTotalGastosPorTanda(widget.tandaId);
    if (mounted) setState(() {});
  }

  Future<void> agregarOEditarGasto({Gasto? gasto}) async {
    final bool esNuevo = gasto == null;
    final descCtrl = TextEditingController(text: esNuevo ? '' : gasto.descripcion);
    final montoCtrl = TextEditingController(text: esNuevo ? '' : gasto.monto.toString());

    final guardado = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(esNuevo ? 'Nuevo Gasto' : 'Editar Gasto'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Descripción')),
            TextField(controller: montoCtrl, decoration: const InputDecoration(labelText: 'Monto'), keyboardType: const TextInputType.numberWithOptions(decimal: true)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () async {
              final monto = double.tryParse(montoCtrl.text) ?? 0.0;
              final desc = descCtrl.text.trim();
              if (monto > 0 && desc.isNotEmpty) {
                if (esNuevo) {
                  await AppDatabase.insertarGasto(Gasto(tandaId: widget.tandaId, descripcion: desc, monto: monto, fecha: DateTime.now()));
                } else {
                  await AppDatabase.actualizarGasto(Gasto(id: gasto.id, tandaId: gasto.tandaId, descripcion: desc, monto: monto, fecha: gasto.fecha));
                }
                Navigator.pop(context, true);
              }
            },
            child: const Text('Guardar'),
          ),
        ],
      ),
    );

    if (guardado == true) {
      await cargar();
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.nombreTanda),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: cargar,
            )
          ],
        ),
        backgroundColor: Theme.of(context).colorScheme.background,
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => agregarOEditarGasto(),
          label: const Text('Nuevo Gasto'),
          icon: const Icon(Icons.add),
        ),
        body: Column(
          children: [
            _buildResumenCard(),
            const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.cake_outlined), text: 'Ingresos'),
                Tab(icon: Icon(Icons.receipt_long_outlined), text: 'Gastos'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _buildIngresosList(),
                  _buildGastosList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- WIDGETS DE LA INTERFAZ ---

  Widget _buildResumenCard() {
    final utilidad = totalPagado - totalGastos;
    final bool esGanancia = utilidad >= 0;

    return Card(
      margin: const EdgeInsets.all(12),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Resumen Financiero', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            _buildResumenRow(
              icon: Icons.arrow_downward,
              color: Colors.green,
              label: 'Total Ingresos (Cobrado)',
              amount: totalPagado,
            ),
            const SizedBox(height: 8),
            _buildResumenRow(
              icon: Icons.arrow_upward,
              color: Colors.red,
              label: 'Total Gastos',
              amount: totalGastos,
            ),
            const Divider(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Utilidad Final', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 20)),
                Text(
                  utilidad.aPesos(),
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: esGanancia ? Colors.green.shade700 : Colors.red.shade700,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildResumenRow({required IconData icon, required Color color, required String label, required double amount}) {
    return Row(
      children: [
        CircleAvatar(
          backgroundColor: color.withOpacity(0.1),
          foregroundColor: color,
          radius: 16,
          child: Icon(icon, size: 20),
        ),
        const SizedBox(width: 12),
        Text(label, style: Theme.of(context).textTheme.bodyMedium),
        const Spacer(),
        Text(amount.aPesos(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ],
    );
  }

  Widget _buildIngresosList() {
    if (ingresos.isEmpty) return const Center(child: Text('No hay ingresos registrados.'));
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 90),
      itemCount: ingresos.length,
      itemBuilder: (_, i) {
        final r = ingresos[i];
        return Card(
          child: ListTile(
            leading: const Icon(Icons.cake_outlined, color: Colors.brown),
            title: Text(r['producto']?.toString() ?? ''),
            subtitle: Text('Cantidad vendida: ${r['cantidadTotal']}'),
            trailing: Text(
              (r['ingresoTotal'] as double? ?? 0.0).aPesos(),
              style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green),
            ),
          ),
        );
      },
    );
  }

  Widget _buildGastosList() {
    if (gastos.isEmpty) return const Center(child: Text('No hay gastos registrados.'));
    final formatoFecha = DateFormat('dd/MM/yyyy');

    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 90),
      itemCount: gastos.length,
      itemBuilder: (_, i) {
        final g = gastos[i];
        return Card(
          child: ListTile(
            leading: const Icon(Icons.receipt_long_outlined, color: Colors.orange),
            title: Text(g.descripcion),
            subtitle: Text(formatoFecha.format(g.fecha.toLocal())),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  g.monto.aPesos(),
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
                ),
                IconButton(
                  icon: const Icon(Icons.edit_outlined, color: Colors.blue),
                  onPressed: () => agregarOEditarGasto(gasto: g),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () async {
                    // Lógica para eliminar Gasto
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}