// lib/producto_detalle_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'database.dart';
import 'formato.dart';
import 'insumo.dart';
import 'producto.dart';

class FacturaFoto {
  int? id;
  String nombre;
  final String path;

  FacturaFoto({this.id, required this.nombre, required this.path});
}

class ProductoDetallePage extends StatefulWidget {
  final Producto producto;
  const ProductoDetallePage({super.key, required this.producto});

  @override
  State<ProductoDetallePage> createState() => _ProductoDetallePageState();
}

class _ProductoDetallePageState extends State<ProductoDetallePage> {
  // Estado para la pestaña de Receta/Insumos
  late Producto _productoActual;
  List<Map<String, dynamic>> _insumosAsignados = [];
  double _costoTotalTanda = 0.0;
  late TextEditingController _rendimientoCtrl;

  // Estado para la pestaña de Facturas
  List<FacturaFoto> _facturas = [];

  @override
  void initState() {
    super.initState();
    _productoActual = widget.producto;
    _rendimientoCtrl = TextEditingController(text: _productoActual.rendimientoTanda.toString());
    _rendimientoCtrl.addListener(() => setState(() {})); // Para que la UI se actualice al escribir
    _cargarDatos();
  }

  @override
  void dispose() {
    _rendimientoCtrl.dispose();
    super.dispose();
  }

  Future<void> _cargarDatos() async {
    await _cargarInsumos();
    await _cargarFacturas();
  }

  Future<void> _cargarInsumos() async {
    final data = await AppDatabase.obtenerInsumosDeProducto(_productoActual.id!);
    double costoCalculado = 0;
    for (var insumo in data) {
      final precio = (insumo['precio'] as num?)?.toDouble() ?? 0.0;
      final cantidad = (insumo['cantidad'] as num?)?.toDouble() ?? 0.0;
      costoCalculado += precio * cantidad;
    }
    if (!mounted) return;
    setState(() {
      _insumosAsignados = data;
      _costoTotalTanda = costoCalculado;
    });
  }

  Future<void> _cargarFacturas() async {
    final lista = await AppDatabase.obtenerFacturasDeProducto(_productoActual.id!);
    if (!mounted) return;
    setState(() {
      _facturas = lista
          .map((map) => FacturaFoto(
                id: map['id'] as int,
                nombre: map['nombre'] as String,
                path: map['path'] as String,
              ))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    // WillPopScope notifica a la página anterior cuando hay cambios al volver atrás
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, true); // Devuelve 'true' para indicar que se debe recargar
        return true;
      },
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text(_productoActual.nombre),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.receipt_long_outlined), text: 'Receta'),
                Tab(icon: Icon(Icons.photo_library_outlined), text: 'Facturas'),
              ],
            ),
          ),
          backgroundColor: Theme.of(context).colorScheme.background,
          body: TabBarView(
            children: [
              _buildRecetaView(),
              _buildFacturasView(),
            ],
          ),
        ),
      ),
    );
  }

  // --- WIDGET PARA LA PESTAÑA DE RECETA ---
  Widget _buildRecetaView() {
    final rendimiento = int.tryParse(_rendimientoCtrl.text) ?? 1;
    final costoPorUnidad = (rendimiento > 0) ? _costoTotalTanda / rendimiento : 0.0;

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _mostrarDialogoAgregarInsumo,
        label: const Text('Añadir Insumo'),
        icon: const Icon(Icons.add),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Card(
              margin: const EdgeInsets.all(12),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _buildInfoRow("Costo Insumos (Tanda):", _costoTotalTanda.aPesos(), const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _rendimientoCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Rendimiento (¿Cuántas unidades salen?)',
                        prefixIcon: Icon(Icons.bakery_dining_outlined),
                      ),
                    ),
                    const Divider(height: 24),
                    _buildInfoRow("Costo por Unidad:", costoPorUnidad.aPesos(), Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.blue.shade800)),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.save_outlined),
                        onPressed: _guardarRendimiento,
                        label: const Text('Guardar Rendimiento'),
                      ),
                    )
                  ],
                ),
              ),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 4).copyWith(bottom: 90),
              itemCount: _insumosAsignados.length,
              itemBuilder: (context, index) {
                final insumo = _insumosAsignados[index];
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.blender_outlined),
                    title: Text(insumo['nombre']),
                    subtitle: Text('${insumo['cantidad']} ${insumo['unidad']}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () async {
                        await AppDatabase.eliminarProductoInsumo(_productoActual.id!, insumo['id']);
                        _cargarInsumos();
                      },
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, TextStyle? style) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [ Text(label, style: Theme.of(context).textTheme.titleMedium), Text(value, style: style) ],
    );
  }

  Future<void> _guardarRendimiento() async {
    final nuevoRendimiento = int.tryParse(_rendimientoCtrl.text) ?? 1;
    final productoActualizado = _productoActual.copyWith(rendimientoTanda: nuevoRendimiento);
    await AppDatabase.actualizarProducto(productoActualizado);
    setState(() {
      _productoActual = productoActualizado;
    });
    FocusScope.of(context).unfocus();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Rendimiento guardado.'), backgroundColor: Colors.green)
    );
  }

  Future<void> _mostrarDialogoAgregarInsumo() async {
    final todosLosInsumos = await AppDatabase.getInsumos();
    Insumo? insumoSeleccionado;
    final cantidadCtrl = TextEditingController();

    final guardado = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Añadir Insumo a la Receta'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<Insumo>(
                    value: insumoSeleccionado,
                    hint: const Text('Selecciona un insumo'),
                    isExpanded: true,
                    items: todosLosInsumos.map((insumo) {
                      return DropdownMenuItem(value: insumo, child: Text(insumo.nombre));
                    }).toList(),
                    onChanged: (value) => setDialogState(() => insumoSeleccionado = value),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: cantidadCtrl,
                    decoration: InputDecoration(labelText: 'Cantidad (${insumoSeleccionado?.unidad ?? ''})'),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  ),
                ],
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
                ElevatedButton(
                  onPressed: (insumoSeleccionado == null) ? null : () async {
                    final cantidad = double.tryParse(cantidadCtrl.text) ?? 0.0;
                    if (cantidad > 0) {
                      await AppDatabase.addInsumoToProducto(_productoActual.id!, insumoSeleccionado!.id!, cantidad);
                      Navigator.pop(context, true);
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );

    if (guardado == true) {
      _cargarInsumos();
    }
  }

  // --- WIDGETS Y MÉTODOS PARA LA PESTAÑA DE FACTURAS ---
  Widget _buildFacturasView() {
    if (_facturas.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.photo_library_outlined, size: 80, color: Colors.grey[300]),
            const SizedBox(height: 16),
            const Text('No hay facturas', style: TextStyle(color: Colors.grey)),
            TextButton.icon(
              icon: const Icon(Icons.add_a_photo_outlined),
              label: const Text('Añadir Primera Factura'),
              onPressed: _agregarFotoFactura,
            ),
          ],
        ),
      );
    }
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: _agregarFotoFactura,
        child: const Icon(Icons.add_a_photo),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: _facturas.length,
        itemBuilder: (_, index) {
          final factura = _facturas[index];
          return Card(
            elevation: 3,
            clipBehavior: Clip.antiAlias,
            child: GridTile(
              footer: GridTileBar(
                backgroundColor: Colors.black54,
                title: Text(factura.nombre, overflow: TextOverflow.ellipsis),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, size: 20, color: Colors.white),
                  onPressed: () => _eliminarFactura(factura, index),
                ),
              ),
              child: Image.file(File(factura.path), fit: BoxFit.cover),
            ),
          );
        },
      ),
    );
  }

  Future<void> _agregarFotoFactura() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile == null) return;

    final directory = await getApplicationDocumentsDirectory();
    final newPath = '${directory.path}/${DateTime.now().millisecondsSinceEpoch}.jpg';
    await File(pickedFile.path).copy(newPath);

    final nombreCtrl = TextEditingController();
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Nombre de la factura"),
        content: TextField(controller: nombreCtrl, decoration: const InputDecoration(hintText: "Ej: El Panadero")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancelar")),
          ElevatedButton(onPressed: () => Navigator.pop(ctx), child: const Text("Guardar")),
        ],
      ),
    );

    await AppDatabase.insertarFactura(_productoActual.id!, nombreCtrl.text.isNotEmpty ? nombreCtrl.text : "Sin nombre", newPath);
    await _cargarFacturas();
  }

  void _eliminarFactura(FacturaFoto factura, int index) async {
    final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text("Confirmar eliminación"),
              content: Text("¿Deseas eliminar la factura '${factura.nombre}'?"),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text("Cancelar")),
                ElevatedButton(
                  onPressed: () async => Navigator.pop(ctx, true),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text("Eliminar"),
                ),
              ],
            ));

    if (confirmed == true) {
      await AppDatabase.eliminarFactura(factura.id!);
      setState(() => _facturas.removeAt(index));
    }
  }
}