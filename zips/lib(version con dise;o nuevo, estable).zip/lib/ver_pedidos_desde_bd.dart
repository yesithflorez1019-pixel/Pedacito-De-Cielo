// lib/ver_pedidos_desde_bd.dart
import 'package:flutter/material.dart';
import 'package:postres_app/formato.dart';
import 'package:postres_app/pedido.dart';
import 'package:postres_app/registrar_pedido.dart';
import 'database.dart';

class VerPedidosDesdeBDPage extends StatefulWidget {
  final int tandaId;
  final String nombreTanda;

  const VerPedidosDesdeBDPage({
    super.key,
    required this.tandaId,
    required this.nombreTanda,
  });

  @override
  State<VerPedidosDesdeBDPage> createState() => _VerPedidosDesdeBDPageState();
}

class _VerPedidosDesdeBDPageState extends State<VerPedidosDesdeBDPage> {
  List<Pedido> listaPedidos = [];
  List<Pedido> pedidosFiltrados = [];

  String filtroBusqueda = '';
  // -1 para Todos, 0 para No, 1 para Sí
  int filtroPagado = -1; 
  int filtroEntregado = -1;

  @override
  void initState() {
    super.initState();
    cargarPedidos();
  }

  Future<void> cargarPedidos() async {
    final pedidos = await AppDatabase.obtenerPedidos(tandaId: widget.tandaId);
    if (!mounted) return;
    setState(() {
      listaPedidos = pedidos..sort((a, b) => a.cliente.compareTo(b.cliente));
      aplicarFiltros();
    });
  }

  void aplicarFiltros() {
    setState(() {
      pedidosFiltrados = listaPedidos.where((pedido) {
        final coincideBusqueda = filtroBusqueda.isEmpty ||
            pedido.cliente.toLowerCase().contains(filtroBusqueda.toLowerCase()) ||
            pedido.detalles.any((d) => d.producto.nombre.toLowerCase().contains(filtroBusqueda.toLowerCase()));

        final coincidePagado = (filtroPagado == -1) || (filtroPagado == 1 && pedido.pagado) || (filtroPagado == 0 && !pedido.pagado);
        final coincideEntregado = (filtroEntregado == -1) || (filtroEntregado == 1 && pedido.entregado) || (filtroEntregado == 0 && !pedido.entregado);

        return coincideBusqueda && coincidePagado && coincideEntregado;
      }).toList();
    });
  }

  void editarPedido(Pedido pedido) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => RegistrarPedidoPage(
          tandaId: widget.tandaId,
          pedidoEditar: pedido,
        ),
      ),
    );
    cargarPedidos();
  }
  
 Future<void> eliminarPedido(int id) async {
    await AppDatabase.eliminarPedidoPorId(id);
    await cargarPedidos();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Pedido eliminado')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.nombreTanda),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: "Refrescar",
            onPressed: cargarPedidos,
          ),
        ],
      ),
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Column(
        children: [
          // Barra de búsqueda
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Buscar por cliente o producto',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                filtroBusqueda = value;
                aplicarFiltros();
              },
            ),
          ),
          
          // **NUEVOS FILTROS DE CÁPSULA**
          _buildFilterSection(),

          // Lista de pedidos
          Expanded(
            child: pedidosFiltrados.isEmpty
                ? const Center(child: Text('No hay pedidos que coincidan'))
                : ListView.builder(
                    padding: const EdgeInsets.only(top: 8, bottom: 90),
                    itemCount: pedidosFiltrados.length,
                    itemBuilder: (context, index) {
                      final pedido = pedidosFiltrados[index];
                      // El resto del card de pedido no cambia
                      return _buildPedidoCard(pedido);
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Nuevo Pedido'),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => RegistrarPedidoPage(tandaId: widget.tandaId),
            ),
          );
          cargarPedidos();
        },
      ),
    );
  }
  
  // Widget para la nueva sección de filtros
  Widget _buildFilterSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFilterChips("Estado de Pago:", filtroPagado, ["No Pagados", "Pagados"], (newIndex) {
            setState(() => filtroPagado = newIndex);
            aplicarFiltros();
          }),
          const SizedBox(height: 4),
          _buildFilterChips("Estado de Entrega:", filtroEntregado, ["No Entregados", "Entregados"], (newIndex) {
            setState(() => filtroEntregado = newIndex);
            aplicarFiltros();
          }),
        ],
      ),
    );
  }

  // Widget reutilizable para crear una fila de chips
  Widget _buildFilterChips(String title, int selectedValue, List<String> labels, ValueChanged<int> onSelected) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          // "Todos"
          ChoiceChip(
            label: const Text('Todos'),
            selected: selectedValue == -1,
            onSelected: (_) => onSelected(-1),
            selectedColor: Theme.of(context).colorScheme.primary,
            labelStyle: TextStyle(color: selectedValue == -1 ? Colors.white : Colors.black),
          ),
          const SizedBox(width: 8),
          // "No"
          ChoiceChip(
            label: Text(labels[0]),
            selected: selectedValue == 0,
            onSelected: (_) => onSelected(0),
            selectedColor: Theme.of(context).colorScheme.primary,
            labelStyle: TextStyle(color: selectedValue == 0 ? Colors.white : Colors.black),
          ),
          const SizedBox(width: 8),
          // "Sí"
          ChoiceChip(
            label: Text(labels[1]),
            selected: selectedValue == 1,
            onSelected: (_) => onSelected(1),
            selectedColor: Theme.of(context).colorScheme.primary,
            labelStyle: TextStyle(color: selectedValue == 1 ? Colors.white : Colors.black),
          ),
        ],
      ),
    );
  }

  // Card para mostrar la información del pedido (sin cambios)
  Widget _buildPedidoCard(Pedido pedido) {
    final total = pedido.total;
    final pagado = pedido.pagoParcial;
    final restante = (total - pagado).clamp(0, total);
    
    return Card(
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          child: Text(
            pedido.cliente.substring(0, 1).toUpperCase(),
            style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold),
          ),
        ),
        title: Text(pedido.cliente, style: Theme.of(context).textTheme.titleLarge),
        subtitle: Text('Total: ${total.aPesos()}', style: TextStyle(color: Colors.grey[700])),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8).copyWith(top: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInfoRow(Icons.location_on_outlined, pedido.direccion),
                const Divider(height: 16),
                _buildInfoRow(Icons.monetization_on_outlined, 'Total: ${total.aPesos()}'),
                _buildInfoRow(Icons.payment_outlined, 'Abono: ${pagado.aPesos()}'),
                _buildInfoRow(Icons.error_outline, 'Debe: ${restante.aPesos()}', color: restante > 0 ? Colors.red.shade700 : Colors.green),
                const Divider(height: 20),
                const Text('Detalles del Pedido:', style: TextStyle(fontWeight: FontWeight.bold)),
                ...pedido.detalles.map((detalle) => Padding(
                  padding: const EdgeInsets.only(left: 8, top: 4),
                  child: Text('• ${detalle.cantidad}x ${detalle.producto.nombre} (${detalle.subtotal.aPesos()})'),
                )),
                const SizedBox(height: 12),
                Row(
                                    children: [
                                      Chip(
                                      labelPadding: const EdgeInsets.symmetric(horizontal: 4.0),

                                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                      avatar: Icon(Icons.check_circle, color: pedido.pagado ? Colors.green : Colors.grey, size: 16), // Ícono un poco más pequeño
                                      label: Text(pedido.pagado ? 'Pagado' : 'Pendiente', style: const TextStyle(fontSize: 12)), // Texto un poco más pequeño
                                      backgroundColor: pedido.pagado ? Colors.green.shade50 : Colors.grey.shade200,
                                    ),
                                    const SizedBox(width: 8),
                                    Chip(

                                      labelPadding: const EdgeInsets.symmetric(horizontal: 4.0),
                                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                      avatar: Icon(Icons.local_shipping, color: pedido.entregado ? Colors.blue : Colors.grey, size: 16),
                                      label: Text(pedido.entregado ? 'Entregado' : 'No Entregado', style: const TextStyle(fontSize: 12)),
                                      backgroundColor: pedido.entregado ? Colors.blue.shade50 : Colors.grey.shade200,
                                    ),
                                        const Spacer(),
                                      IconButton(
                                        icon: const Icon(Icons.edit, color: Colors.orange),
                                        onPressed: () => editarPedido(pedido),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete, color: Colors.red),
                                        onPressed: () async {
                                          final confirmacion = await showDialog<bool>(
                                            context: context,
                                            builder: (context) => AlertDialog(
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(20),
                                              ),
                                              title: const Text(
                                                '¿Eliminar pedido?',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.pinkAccent,
                                                ),
                                              ),
                                              content: const Text(
                                                'Esta acción no se puede deshacer.\n¿Estás seguro que deseas eliminarlo?',
                                                style: TextStyle(color: Colors.black87),
                                              ),
                                              actionsPadding: const EdgeInsets.symmetric(
                                                  horizontal: 16, vertical: 8),
                                              actions: [
                                                TextButton(
                                                  style: TextButton.styleFrom(
                                                    foregroundColor: Colors.grey[700],
                                                  ),
                                                  onPressed: () => Navigator.pop(context, false),
                                                  child: const Text('Cancelar'),
                                                ),
                                                ElevatedButton(
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor: Colors.pinkAccent,
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                    ),
                                                  ),
                                                  onPressed: () => Navigator.pop(context, true),
                                                  child: const Text('Eliminar'),
                                                ),
                                              ],
                                            ),
                                          );

                                          if (confirmacion == true) {
                                            eliminarPedido(pedido.id!);
                                          }
                                        },
                                      ),
                                    ],
                                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.grey[600], size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: color, fontSize: 15))),
        ],
      ),
    );
  }
}