import 'package:flutter/material.dart';
import 'package:postres_app/database.dart';
import 'package:postres_app/formato.dart';

class ReportesPage extends StatefulWidget {
  const ReportesPage({super.key});

  @override
  State<ReportesPage> createState() => _ReportesPageState();
}

class _ReportesPageState extends State<ReportesPage> {
  late Future<Map<String, dynamic>> _informesFuture;

  @override
  void initState() {
    super.initState();
    _cargarInformes();
  }

  Future<void> _cargarInformes() async {
    _informesFuture = _obtenerDatosGenerales();
  }

  Future<Map<String, dynamic>> _obtenerDatosGenerales() async {
    final totalIngresos = await AppDatabase.obtenerTotalIngresosPorTanda(1); // Ejemplo con tanda 1
    final totalGastos = await AppDatabase.obtenerTotalGastosPorTanda(1); // Ejemplo con tanda 1
    final totalPedidos = await AppDatabase.obtenerPedidos();
    final productosInventario = await AppDatabase.obtenerProductosDeTanda(1); // Ejemplo con tanda 1
    
    // Obtener los productos más vendidos
    final productosVendidos = await AppDatabase.obtenerIngresosPorProducto(1);
    productosVendidos.sort((a, b) => (b['cantidadTotal'] as num).compareTo(a['cantidadTotal'] as num));

    // Obtener el balance total de finanzas personales
    final cuentas = await AppDatabase.obtenerCuentas();
    final balancePersonal = cuentas.fold<double>(0.0, (sum, cuenta) => sum + cuenta.balance);

    return {
      'totalIngresos': totalIngresos,
      'totalGastos': totalGastos,
      'gananciaNeta': totalIngresos - totalGastos,
      'totalPedidos': totalPedidos.length,
      'totalProductosInventario': productosInventario.length,
      'productosMasVendidos': productosVendidos.take(3).toList(),
      'balancePersonal': balancePersonal,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Panel de Control'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _cargarInformes();
              });
            },
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _informesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return const Center(child: Text('No se encontraron datos.'));
          }

          final data = snapshot.data!;
          final gananciaNeta = data['gananciaNeta'] as double;
          final colorGanancia = gananciaNeta >= 0 ? Colors.green.shade700 : Colors.red.shade700;
          final productosVendidos = data['productosMasVendidos'] as List;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Sección de Resumen General
              _buildReportCard(
                title: 'Resumen General del Negocio',
                content: [
                  _buildMetricRow(Icons.arrow_upward, 'Ingresos Totales', (data['totalIngresos'] as double).aPesos(), Colors.green),
                  _buildMetricRow(Icons.arrow_downward, 'Gastos Totales', (data['totalGastos'] as double).aPesos(), Colors.red),
                  const Divider(),
                  _buildMetricRow(Icons.bar_chart, 'Ganancia Neta', gananciaNeta.aPesos(), colorGanancia),
                ],
              ),
              const SizedBox(height: 16),
              // Sección de Inventario y Pedidos
              _buildReportCard(
                title: 'Pedidos y Productos',
                content: [
                  _buildMetricRow(Icons.shopping_cart, 'Total de Pedidos', '${data['totalPedidos']} pedidos'),
                  const Divider(),
                  _buildMetricRow(Icons.emoji_events, 'Productos Más Vendidos', ''),
                  ...productosVendidos.map((prod) => Padding(
                    padding: const EdgeInsets.only(left: 32, top: 4),
                    child: Text('• ${prod['producto']} (${prod['cantidadTotal']} uds.)'),
                  )).toList(),
                ],
              ),
              const SizedBox(height: 16),
              // Sección de Finanzas Personales
              _buildReportCard(
                title: 'Finanzas Personales',
                content: [
                  _buildMetricRow(Icons.attach_money, 'Balance Total', (data['balancePersonal'] as double).aPesos(), Colors.blue),
                  const Text('Nota: Este balance es de tus cuentas personales.', style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey)),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildReportCard({required String title, required List<Widget> content}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const Divider(height: 24),
            ...content,
          ],
        ),
      ),
    );
  }

  Widget _buildMetricRow(IconData icon, String label, String value, [Color? color]) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Icon(icon, color: color ?? Theme.of(context).colorScheme.onSurface),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 16))),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }
}