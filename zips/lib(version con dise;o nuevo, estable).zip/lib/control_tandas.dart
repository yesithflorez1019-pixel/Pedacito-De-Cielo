// lib/control_tandas.dart
import 'package:flutter/material.dart';
import 'package:postres_app/crear_tanda_page.dart';
import 'package:postres_app/database.dart';
import 'package:postres_app/informe_ingresos.dart';
import 'package:postres_app/tanda.dart';
import 'package:postres_app/ver_pedidos_desde_bd.dart';

class ControlTandasPage extends StatefulWidget {
  const ControlTandasPage({super.key});

  @override
  State<ControlTandasPage> createState() => _ControlTandasPageState();
}

class _ControlTandasPageState extends State<ControlTandasPage> {
  List<Tanda> tandas = [];
  Map<int, int> pedidosCount = {};

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    final data = await AppDatabase.obtenerTandasConConteo();
    if (!mounted) return;
    setState(() {
      tandas = data.map((e) => Tanda.fromMap(e)).toList();
      pedidosCount = {
        for (var e in data) e['id'] as int: e['pedidosCount'] as int
      };
    });
  }


  Future<void> crearOEditarTanda({Tanda? tanda}) async {
    final guardado = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => CrearTandaPage(tandaExistente: tanda),
      ),
    );
 

    if (guardado == true) {
      await cargar();
    }
  }

  Future<void> eliminar(Tanda tanda) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar tanda'),
        content: const Text(
            '¿Seguro que deseas eliminar esta tanda? Se eliminarán sus pedidos y gastos.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Eliminar'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );

    if (ok == true && tanda.id != null) {
      await AppDatabase.eliminarTanda(tanda.id!);
      await cargar();
    }
  }

  void abrirTanda(Tanda tanda) async {
    if (tanda.id == null) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TandaHomePage(
          tandaId: tanda.id!,
          nombreTanda: tanda.nombre,
        ),
      ),
    );
    await cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tandas y Pedidos'),
      ),
      backgroundColor: Theme.of(context).colorScheme.background,
      floatingActionButton: FloatingActionButton(
        onPressed: () => crearOEditarTanda(),
        child: const Icon(Icons.add),
      ),
      body: tandas.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.collections_bookmark_outlined,
                      size: 80, color: Colors.grey[300]),
                  const SizedBox(height: 16),
                  Text('No hay tandas creadas',
                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall
                          ?.copyWith(color: Colors.grey)),
                  const SizedBox(height: 8),
                  Text('Toca el botón + para crear la primera.',
                      style: TextStyle(color: Colors.grey[600], fontSize: 16)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.only(top: 8, bottom: 80),
              itemCount: tandas.length,
              itemBuilder: (context, i) {
                final t = tandas[i];
                final count = pedidosCount[t.id ?? 0] ?? 0;
                return Card(
                  child: InkWell(
                    onTap: () => abrirTanda(t),
                    borderRadius: BorderRadius.circular(16),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.1),
                            radius: 24,
                            child: Icon(Icons.collections_bookmark_outlined,
                                size: 28,
                                color: Theme.of(context).colorScheme.primary),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(t.nombre,
                                    style:
                                        Theme.of(context).textTheme.titleLarge),
                                const SizedBox(height: 4),
                                Text(
                                  '$count pedidos',
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.grey[600]),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                              icon: const Icon(Icons.edit_outlined),
                              onPressed: () => crearOEditarTanda(tanda: t)),
                          IconButton(
                              icon:
                                  const Icon(Icons.delete_outline, color: Colors.red),
                              onPressed: () => eliminar(t)),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class TandaHomePage extends StatelessWidget {
  final int tandaId;
  final String nombreTanda;
  const TandaHomePage(
      {super.key, required this.tandaId, required this.nombreTanda});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(nombreTanda),
      ),
      backgroundColor: Theme.of(context).colorScheme.background,
      body: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        padding: const EdgeInsets.all(16),
        children: [
          _buildOptionCard(
            context,
            icon: Icons.receipt_long_outlined,
            label: "Control de pedidos",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => VerPedidosDesdeBDPage(
                      tandaId: tandaId, nombreTanda: nombreTanda),
                ),
              );
            },
          ),
          _buildOptionCard(
            context,
            icon: Icons.bar_chart_outlined,
            label: "Informe de ingresos",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => InformeIngresosPage(
                      tandaId: tandaId, nombreTanda: nombreTanda),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildOptionCard(BuildContext context,
      {required IconData icon,
      required String label,
      required VoidCallback onTap}) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text(label,
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}