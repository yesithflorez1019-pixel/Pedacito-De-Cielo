// lib/crear_tanda_page.dart
import 'package:flutter/material.dart';
import 'package:postres_app/database.dart';
import 'package:postres_app/producto.dart';
import 'package:postres_app/tanda.dart';

class CrearTandaPage extends StatefulWidget {
  final Tanda? tandaExistente;
  const CrearTandaPage({super.key, this.tandaExistente});

  @override
  State<CrearTandaPage> createState() => _CrearTandaPageState();
}

class _CrearTandaPageState extends State<CrearTandaPage> {
  // --- Controladores y Estado ---
  final _nombreTandaCtrl = TextEditingController();
  final _searchCtrl = TextEditingController();

  List<Producto> _todosLosProductos = [];
  List<Producto> _productosFiltrados = [];

  // Mapa para guardar los productos seleccionados y su stock. Ej: {productoId: stock}
  Map<int, int> _productosSeleccionados = {};

  final Map<int, TextEditingController> _stockControllers = {};

  @override
  void initState() {
    super.initState();
    _cargarProductos();
    _searchCtrl.addListener(_filtrarProductos);

    // --- CORRECCIÓN AQUÍ ---
    // Si estamos editando una tanda, cargamos sus datos.
    if (widget.tandaExistente != null) {
      _nombreTandaCtrl.text = widget.tandaExistente!.nombre;
      _cargarDatosTanda();
    }
  }

  @override
  void dispose() {
    _nombreTandaCtrl.dispose();
    _searchCtrl.dispose();
    _stockControllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  Future<void> _cargarProductos() async {
    _todosLosProductos = await AppDatabase.obtenerProductos();
    setState(() {
      _productosFiltrados = _todosLosProductos;
    });
  }

  // --- NUEVA FUNCIÓN AÑADIDA ---
  Future<void> _cargarDatosTanda() async {
    if (widget.tandaExistente?.id == null) return;
    
    final productosTanda = await AppDatabase.obtenerProductosDeTanda(widget.tandaExistente!.id!);

    setState(() {
      _productosSeleccionados.clear();
      _stockControllers.clear();

      for (var p in productosTanda) {
        final productoId = p['productoId'] as int;
        final stockActual = p['stock'] as int;
        
        _productosSeleccionados[productoId] = stockActual;
        _stockControllers[productoId] = TextEditingController(text: stockActual.toString());
      }
    });
  }

  void _filtrarProductos() {
    final query = _searchCtrl.text.toLowerCase();
    setState(() {
      _productosFiltrados = _todosLosProductos
          .where((p) => p.nombre.toLowerCase().contains(query))
          .toList();
    });
  }

  void _onProductoSeleccionado(Producto producto) {
    setState(() {
      if (_productosSeleccionados.containsKey(producto.id)) {
        // Si ya está seleccionado, lo quitamos
        _productosSeleccionados.remove(producto.id);
        _stockControllers.remove(producto.id)?.dispose();
      } else {
        // Si no está, lo añadimos con un stock inicial de 1
        _productosSeleccionados[producto.id!] = 1;
        _stockControllers[producto.id!] = TextEditingController(text: '1');
      }
    });
  }

  void _actualizarStock(int productoId, String stockStr) {
    final stock = int.tryParse(stockStr) ?? 0;
    _productosSeleccionados[productoId] = stock;
  }

  Future<void> _guardarTanda() async {
    final nombreTanda = _nombreTandaCtrl.text.trim();
    if (nombreTanda.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Por favor, ingresa un nombre para la tanda.')));
      return;
    }
    
    final productosAGuardar = Map.of(_productosSeleccionados)
        ..removeWhere((key, value) => value <= 0);

    if (productosAGuardar.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Añade al menos un producto con stock.')));
      return;
    }

    if (widget.tandaExistente == null) {
      // Lógica para crear una tanda nueva (ya funciona)
      final nuevaTanda = Tanda(nombre: nombreTanda);
      final tandaId = await AppDatabase.insertarTanda(nuevaTanda);
      await AppDatabase.addProductosToTanda(tandaId, productosAGuardar);
    } else {
      // --- CORRECCIÓN AQUÍ ---
      // Lógica para actualizar una tanda existente
      final tandaId = widget.tandaExistente!.id!;
      final tandaActualizada = Tanda(id: tandaId, nombre: nombreTanda);
      await AppDatabase.actualizarTanda(tandaActualizada);
      await AppDatabase.actualizarProductosDeTanda(tandaId, productosAGuardar);
    }

    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            widget.tandaExistente == null ? "Nueva Tanda" : "Editar Tanda"),
        actions: [
          IconButton(
            icon: const Icon(Icons.save_outlined),
            onPressed: _guardarTanda,
            tooltip: 'Guardar Tanda',
          )
        ],
      ),
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nombreTandaCtrl,
              decoration: const InputDecoration(labelText: 'Nombre de la tanda'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(
                  labelText: 'Buscar producto',
                  prefixIcon: Icon(Icons.search)),
            ),
            // --- SELECTOR HORIZONTAL DE PRODUCTOS ---
            const SizedBox(height: 16),
            SizedBox(
              height: 150,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _productosFiltrados.length,
                itemBuilder: (context, index) {
                  final producto = _productosFiltrados[index];
                  final isSelected =
                      _productosSeleccionados.containsKey(producto.id);
                  return _buildProductoCard(producto, isSelected);
                },
              ),
            ),
            // --- RESUMEN DE PRODUCTOS SELECCIONADOS ---
            const Divider(height: 32),
            Text('Productos en esta Tanda',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Expanded(
              child: _productosSeleccionados.isEmpty
                  ? const Center(
                      child: Text('Selecciona productos de la lista de arriba.'))
                  : _buildResumenList(),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildProductoCard(Producto producto, bool isSelected) {
    return GestureDetector(
      onTap: () => _onProductoSeleccionado(producto),
      child: Card(
        elevation: isSelected ? 4 : 1,
        color: isSelected ? Colors.pink.shade50 : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: isSelected ? Theme.of(context).colorScheme.primary : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Container(
          width: 130,
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // --- CORRECCIÓN AQUÍ ---
              // Envolvemos el Text en un Expanded y un FittedBox
              Expanded(
                flex: 2, // Le damos un poco más de espacio al texto
                child: FittedBox(
                  fit: BoxFit.scaleDown, // Esto hace que el texto se encoja si es necesario
                  child: Text(
                    producto.nombre,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const Spacer(flex: 1), // Usamos Spacer en lugar de SizedBox para mejor distribución
              if (isSelected)
                _buildStockInput(producto.id!)
              else
                Icon(Icons.add_circle_outline, color: Theme.of(context).colorScheme.primary),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStockInput(int productoId) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('Stock:', style: TextStyle(fontSize: 14)),
        const SizedBox(width: 8),
        SizedBox(
          width: 50,
          child: TextField(
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            controller: _stockControllers[productoId],
            onChanged: (value) => _actualizarStock(productoId, value),
            decoration: const InputDecoration(
              isDense: true,
              contentPadding: EdgeInsets.all(8),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildResumenList() {
    final productosEnResumen = _todosLosProductos
        .where((p) => _productosSeleccionados.containsKey(p.id))
        .toList();

    return ListView.builder(
      itemCount: productosEnResumen.length,
      itemBuilder: (context, index) {
        final producto = productosEnResumen[index];
        final stock = _productosSeleccionados[producto.id] ?? 0;
        return Card(
          child: ListTile(
            leading: const Icon(Icons.check_box_outlined),
            title: Text(producto.nombre),
            trailing: Text('Stock: $stock',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        );
      },
    );
  }
}