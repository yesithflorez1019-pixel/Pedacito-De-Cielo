import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:postres_app/database.dart';
import 'package:postres_app/formato.dart';

import 'cuenta.dart';
import 'transaccion.dart';
import 'registrar_transaccion_page.dart';

class HistorialCuentaPage extends StatefulWidget {
  final Cuenta cuenta;
  const HistorialCuentaPage({super.key, required this.cuenta});

  @override
  State<HistorialCuentaPage> createState() => _HistorialCuentaPageState();
}

class _HistorialCuentaPageState extends State<HistorialCuentaPage> {
  late Future<List<Transaccion>> _transaccionesFuture;

  @override
  void initState() {
    super.initState();
    _cargarTransacciones();
  }

  Future<void> _cargarTransacciones() async {
    _transaccionesFuture = AppDatabase.obtenerTransaccionesPorCuenta(widget.cuenta.id!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.cuenta.nombre),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _cargarTransacciones();
              });
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Transaccion>>(
        future: _transaccionesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hay transacciones registradas.'));
          } else {
            final transacciones = snapshot.data!;
            return ListView.builder(
              itemCount: transacciones.length,
              itemBuilder: (context, index) {
                final transaccion = transacciones[index];
                final esIngreso = transaccion.tipo == 'ingreso';
                final icono = esIngreso ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded;
                final color = esIngreso ? Colors.green.shade700 : Colors.red.shade700;

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  elevation: 2,
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: color.withOpacity(0.2),
                      child: Icon(icono, color: color),
                    ),
                    title: Text(
                      '${transaccion.monto.aPesos()}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold, color: color),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Text(
                          'Categoría: ${transaccion.categoria}',
                          style: TextStyle(color: Colors.grey.shade700),
                        ),
                        if (transaccion.descripcion != null && transaccion.descripcion!.isNotEmpty)
                          Text('Descripción: ${transaccion.descripcion!}', style: TextStyle(color: Colors.grey.shade700)),
                      ],
                    ),
                    trailing: Text(DateFormat('dd/MM/yyyy').format(transaccion.fecha)),
                  ),
                );
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            // CORRECCIÓN: Ahora enviamos la cuenta a la siguiente pantalla
            MaterialPageRoute(builder: (context) => RegistrarTransaccionPage(cuentaPorDefecto: widget.cuenta)),
          );
          setState(() {
            _cargarTransacciones();
          });
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}