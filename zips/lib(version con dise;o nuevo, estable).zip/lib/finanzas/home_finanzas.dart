import 'package:flutter/material.dart';
import 'package:postres_app/database.dart';
import 'package:postres_app/formato.dart';

import 'cuenta.dart';
import 'registrar_cuenta_page.dart';
import 'historial_cuenta_page.dart'; // Importamos la nueva pantalla

class HomeFinanzasPage extends StatefulWidget {
  const HomeFinanzasPage({super.key});

  @override
  State<HomeFinanzasPage> createState() => _HomeFinanzasPageState();
}

class _HomeFinanzasPageState extends State<HomeFinanzasPage> {
  late Future<List<Cuenta>> _cuentasFuture;

  @override
  void initState() {
    super.initState();
    _cargarCuentas();
  }

  Future<void> _cargarCuentas() async {
    _cuentasFuture = AppDatabase.obtenerCuentas();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Finanzas'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _cargarCuentas();
              });
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Cuenta>>(
        future: _cuentasFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hay cuentas registradas.'));
          } else {
            final cuentas = snapshot.data!;
            final totalBalance = cuentas.fold(0.0, (sum, item) => sum + item.balance);

            return Column(
              children: [
                // Sección de balance total
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(24),
                      bottomRight: Radius.circular(24),
                    ),
                  ),
                  child: Center(
                    child: Column(
                      children: [
                        Text(
                          'Balance total',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.grey.shade700),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          totalBalance.aPesos(),
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: totalBalance >= 0 ? Colors.green.shade700 : Colors.red.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Grid de cuentas
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 16,
                      crossAxisSpacing: 16,
                      childAspectRatio: 1,
                    ),
                    itemCount: cuentas.length,
                    itemBuilder: (context, index) {
                      final cuenta = cuentas[index];
                      return InkWell(
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => HistorialCuentaPage(cuenta: cuenta)),
                          );
                          setState(() {
                            _cargarCuentas();
                          });
                        },
                        child: Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 4,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Colors.white, Theme.of(context).colorScheme.surface.withOpacity(0.8)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.account_balance_wallet, size: 50, color: Theme.of(context).colorScheme.primary),
                                  const SizedBox(height: 12),
                                  Text(
                                    cuenta.nombre,
                                    style: Theme.of(context).textTheme.titleLarge,
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    '${cuenta.balance.aPesos()}',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      color: cuenta.balance > 0 ? Colors.green.shade700 : Colors.red.shade700,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Nueva Cuenta'),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const RegistrarCuentaPage()),
          );
          setState(() {
            _cargarCuentas();
          });
        },
      ),
    );
  }
}