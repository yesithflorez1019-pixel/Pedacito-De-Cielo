import 'package:flutter/material.dart';
import 'package:postres_app/database.dart';
import 'package:postres_app/finanzas/cuenta.dart';

class RegistrarCuentaPage extends StatefulWidget {
  const RegistrarCuentaPage({super.key});

  @override
  State<RegistrarCuentaPage> createState() => _RegistrarCuentaPageState();
}

class _RegistrarCuentaPageState extends State<RegistrarCuentaPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _balanceController = TextEditingController(text: '0');

  @override
  void dispose() {
    _nombreController.dispose();
    _balanceController.dispose();
    super.dispose();
  }

  Future<void> _guardarCuenta() async {
    if (_formKey.currentState!.validate()) {
      final nuevaCuenta = Cuenta(
        nombre: _nombreController.text,
        balance: double.tryParse(_balanceController.text) ?? 0.0,
      );
      await AppDatabase.insertarCuenta(nuevaCuenta);
      if (mounted) {
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    Color? colorPrimario = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Nueva Cuenta'),
      ),
      body: Container(
        color: Theme.of(context).colorScheme.background,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                // Encabezado visual
                Center(
                  child: Column(
                    children: [
                      Icon(Icons.account_balance_wallet, size: 60, color: colorPrimario),
                      const SizedBox(height: 8),
                      Text(
                        'Crea una nueva cuenta',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Dale un nombre y un saldo inicial',
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                // Formulario de campos
                Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        TextFormField(
                          controller: _nombreController,
                          decoration: InputDecoration(
                            labelText: 'Nombre de la cuenta',
                            prefixIcon: Icon(Icons.label, color: colorPrimario),
                            hintText: 'Ej. Ahorros, Gastos diarios',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'El nombre es requerido.';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _balanceController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                            labelText: 'Balance inicial',
                            prefixIcon: Icon(Icons.attach_money, color: colorPrimario),
                            hintText: 'Ej. 500.000',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'El balance inicial es requerido.';
                            }
                            if (double.tryParse(value) == null) {
                              return 'Ingrese un número válido.';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                // Botón para guardar
                ElevatedButton.icon(
                  onPressed: _guardarCuenta,
                  icon: const Icon(Icons.save),
                  label: const Text('Guardar Cuenta'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: colorPrimario,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}