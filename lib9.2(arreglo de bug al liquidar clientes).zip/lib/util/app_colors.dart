
import 'package:flutter/material.dart';

const Color kColorHeader1 = Color(0xFFE3AADD);
const Color kColorHeader2 = Color(0xFFC8A8E9);
const Color kColorPrimary = Color(0xFFEB8DB5);
const Color kColorTextDark = Color(0xFF333333);
const Color kColorBackground1 = Color(0xFFFCFAF2);
const Color kColorBackground2 = Color(0xFFF6BCBA);