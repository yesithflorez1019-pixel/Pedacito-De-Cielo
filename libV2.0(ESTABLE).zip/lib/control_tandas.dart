import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:postres_app/crear_tanda_page.dart';
import 'package:postres_app/database.dart';
import 'package:postres_app/informe_ingresos.dart';
import 'package:postres_app/tanda.dart';
import 'package:postres_app/ver_pedidos_desde_bd.dart';


class ControlTandasPage extends StatefulWidget {
  const ControlTandasPage({super.key});

  @override
  State<ControlTandasPage> createState() => _ControlTandasPageState();
}

class _ControlTandasPageState extends State<ControlTandasPage> {
  List<Tanda> tandas = [];
  Map<int, int> pedidosCount = {};

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    final data = await AppDatabase.obtenerTandasConConteo();
    if (!mounted) return;
    setState(() {
      tandas = data.map((e) => Tanda.fromMap(e)).toList();
      pedidosCount = {
        for (var e in data) e['id'] as int: e['pedidosCount'] as int
      };
    });
  }

  Future<void> crearOEditarTanda({Tanda? tanda}) async {
    final guardado = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => CrearTandaPage(tandaExistente: tanda),
      ),
    );

    if (guardado == true) {
      await cargar();
    }
  }

  Future<void> eliminar(Tanda tanda) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar tanda'),
        content: const Text(
            '¿Seguro que deseas eliminar esta tanda? Se eliminarán sus pedidos y gastos.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );

    if (ok == true && tanda.id != null) {
      await AppDatabase.eliminarTanda(tanda.id!);
      await cargar();
    }
  }

  void abrirTanda(Tanda tanda) async {
    if (tanda.id == null) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TandaHomePage(
          tandaId: tanda.id!,
          nombreTanda: tanda.nombre,
        ),
      ),
    );
    await cargar();
  }

  @override
  Widget build(BuildContext context) {
    final Color colorHeader1 = const Color(0xFFE3AADD);
    final Color colorHeader2 = const Color(0xFFD4A3C4);
    final Color colorFondoClaro = const Color(0xFFFCFAF2);
    final Color colorFondoOscuro = const Color(0xFFF6BCBA);
    final Color colorTextoOscuro = Theme.of(context).textTheme.bodyMedium?.color ?? Colors.black87;

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [colorFondoClaro, colorFondoOscuro],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          ClipPath(
            clipper: HeaderClipper(),
            child: Container(
              height: 250,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [colorHeader1, colorHeader2],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Positioned(
            top: 50,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 20),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Tandas y Pedidos',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.refresh, color: Colors.white),
                    onPressed: cargar,
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 150.0),
            child: tandas.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.collections_bookmark_outlined,
                            size: 80, color: colorTextoOscuro.withOpacity(0.3)),
                        const SizedBox(height: 16),
                        Text('No hay tandas creadas',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(color: colorTextoOscuro.withOpacity(0.6))),
                        const SizedBox(height: 8),
                        Text('Toca el botón "+" para crear la primera.',
                            style: TextStyle(color: colorTextoOscuro.withOpacity(0.5), fontSize: 16)),
                      ],
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: cargar,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      itemCount: tandas.length,
                      itemBuilder: (context, i) {
                        final t = tandas[i];
                        final count = pedidosCount[t.id ?? 0] ?? 0;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(16),
                                  color: Colors.white.withOpacity(0.3),
                                  border: Border.all(color: Colors.white.withOpacity(0.1), width: 0.8),
                                ),
                                child: InkWell(
                                  onTap: () => abrirTanda(t),
                                  borderRadius: BorderRadius.circular(16),
                                  child: Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                                          radius: 24,
                                          child: Icon(Icons.collections_bookmark_outlined,
                                              size: 28,
                                              color: Theme.of(context).colorScheme.primary),
                                        ),
                                        const SizedBox(width: 16),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(t.nombre,
                                                  style: Theme.of(context).textTheme.titleLarge?.copyWith(color: colorTextoOscuro)),
                                              const SizedBox(height: 4),
                                              Text(
                                                '$count pedidos',
                                                style: TextStyle(
                                                    fontSize: 14, color: colorTextoOscuro.withOpacity(0.6)),
                                              ),
                                            ],
                                          ),
                                        ),
                                        IconButton(
                                            icon: const Icon(Icons.edit_outlined, color: Colors.white),
                                            onPressed: () => crearOEditarTanda(tanda: t)),
                                        IconButton(
                                            icon: const Icon(Icons.delete_outline, color: Colors.red),
                                            onPressed: () => eliminar(t)),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => crearOEditarTanda(),
        child: const Icon(Icons.add),
      ),
    );
  }
}

// Custom Clipper para la forma irregular del encabezado (reutilizado de otras páginas)
class HeaderClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height);
    var firstControlPoint = Offset(size.width * 0.25, size.height);
    var firstEndPoint = Offset(size.width * 0.5, size.height - 30);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy, firstEndPoint.dx, firstEndPoint.dy);
    var secondControlPoint = Offset(size.width * 0.75, size.height - 60);
    var secondEndPoint = Offset(size.width, size.height - 40);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy, secondEndPoint.dx, secondEndPoint.dy);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class TandaHomePage extends StatelessWidget {
  final int tandaId;
  final String nombreTanda;
  const TandaHomePage(
      {super.key, required this.tandaId, required this.nombreTanda});

  @override
  Widget build(BuildContext context) {
    final Color colorHeader1 = const Color(0xFFE3AADD);
    final Color colorHeader2 = const Color(0xFFD4A3C4);
    final Color colorFondoClaro = const Color(0xFFFCFAF2);
    final Color colorFondoOscuro = const Color(0xFFF6BCBA);


    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [colorFondoClaro, colorFondoOscuro],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          ClipPath(
            clipper: HeaderClipper(),
            child: Container(
              height: 250,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [colorHeader1, colorHeader2],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Positioned(
            top: 50,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 20),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      nombreTanda,
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 250.0),
            child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              padding: const EdgeInsets.all(16),
              children: [
                _buildOptionCard(
                  context,
                  icon: Icons.receipt_long_outlined,
                  label: "Control de pedidos",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => VerPedidosDesdeBDPage(
                            tandaId: tandaId, nombreTanda: nombreTanda),
                      ),
                    );
                  },
                ),
                _buildOptionCard(
                  context,
                  icon: Icons.bar_chart_outlined,
                  label: "Informe de ingresos",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => InformeIngresosPage(
                            tandaId: tandaId, nombreTanda: nombreTanda),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOptionCard(BuildContext context,
      {required IconData icon,
      required String label,
      required VoidCallback onTap}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: Colors.white.withOpacity(0.3),
            border: Border.all(color: Colors.white.withOpacity(0.1), width: 0.8),
          ),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, size: 40, color: Theme.of(context).colorScheme.primary),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    label,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).textTheme.bodyMedium?.color,
                        ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}