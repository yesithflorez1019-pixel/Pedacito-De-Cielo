import 'dart:ui'; // Necesario para el BackdropFilter

import 'package:flutter/material.dart';
import 'package:postres_app/inventario_page.dart';
import 'ver_productos.dart';
import 'control_tandas.dart';
import 'informe_no_pagados.dart';
import 'finanzas/home_finanzas.dart';
import 'reportes_page.dart';

void main() {
  runApp(const PedacitoDeCielo());
}

class PedacitoDeCielo extends StatelessWidget {
  const PedacitoDeCielo({super.key});

  @override
  Widget build(BuildContext context) {
    // Colores de la nueva paleta
    const Color colorFondo1 = Color(0xFFFCFAF2); // Off-white
    const Color colorPrimario = Color(0xFFEB8DB5); // Rosa fuerte
    const Color colorTarjeta = Color(0xFFFFFFFF); // Blanco para el efecto acrílico
    const Color colorTextoOscuro = Color(0xFF333333); // Texto oscuro para el fondo claro

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pedacito de Cielo',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: colorPrimario,
          primary: colorPrimario,
          background: colorFondo1, // Color de fondo base
          surface: colorTarjeta,
          brightness: Brightness.light,
        ),
        textTheme: const TextTheme(
          headlineMedium: TextStyle(fontWeight: FontWeight.bold, color: colorTextoOscuro, fontSize: 24),
          titleLarge: TextStyle(fontWeight: FontWeight.bold, color: colorTextoOscuro, fontSize: 18),
          bodyMedium: TextStyle(fontSize: 16.0, color: colorTextoOscuro),
          labelLarge: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0, color: Colors.white),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          foregroundColor: colorTextoOscuro,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: colorTextoOscuro),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          clipBehavior: Clip.antiAlias,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: colorPrimario,
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: colorPrimario,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
            textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withOpacity(0.8),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: colorPrimario, width: 2.0),
          ),
        ),
        dialogTheme: DialogThemeData(
          backgroundColor: colorFondo1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      home: const HomePage(),
    );
  }
}

// Custom Clipper para la forma irregular del encabezado
class HeaderClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height);
    var firstControlPoint = Offset(size.width * 0.25, size.height);
    var firstEndPoint = Offset(size.width * 0.5, size.height - 30);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy, firstEndPoint.dx, firstEndPoint.dy);
    var secondControlPoint = Offset(size.width * 0.75, size.height - 60);
    var secondEndPoint = Offset(size.width, size.height - 40);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy, secondEndPoint.dx, secondEndPoint.dy);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Tus opciones originales de la app, adaptadas al nuevo diseño
    final options = <_MenuOption>[
      _MenuOption(
        icon: Icons.cake_outlined,
        label: 'Productos',
        color: const Color(0xFFEB8DB5), // Rosa/morado
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const VerProductosPage())),
      ),
      _MenuOption(
        icon: Icons.list_alt_outlined,
        label: 'Tandas y Pedidos',
        color: const Color(0xFFD4A3C4), // Morado pastel
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ControlTandasPage())),
      ),
      _MenuOption(
        icon: Icons.payment_outlined,
        label: 'Informe de Deudas',
        color: const Color(0xFFFFA07A), // Salmón
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const InformeNoPagadosPage())),
      ),
      _MenuOption(
        icon: Icons.inventory_2_outlined,
        label: 'Inventario',
        color: const Color(0xFFA8D1E7), // Azul claro
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const InventarioPage())),
      ),
      _MenuOption(
        icon: Icons.attach_money,
        label: 'Finanzas Personales',
        color: const Color(0xFFFFBFC5), // Rosa pastel
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const HomeFinanzasPage())),
      ),
      _MenuOption(
        icon: Icons.bar_chart,
        label: 'Panel de Reportes',
        color: const Color(0xFFB0C4DE), // Azul pizarra
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ReportesPage())),
      ),
    ];

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Stack(
        children: [
          // Fondo de la app con un degradado sutil
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFCFAF2), Color(0xFFF6BCBA)], // Degradado de beige a coral
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          // Fondo del encabezado con forma irregular
          ClipPath(
            clipper: HeaderClipper(),
            child: Container(
              height: 250,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFE3AADD), Color(0xFFD4A3C4)], // Degradado de la paleta
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          // Contenido del encabezado (Back y Texto)
          Positioned(
            top: 90,
            left: 0,
            right: 0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    
                  ),
                ),
                const SizedBox(height: 20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.0),
                  child: Text(
                    'Pedacito de Cielo',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.0),
                  child: Text(
                    'Para mi princesa karolcita',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white70,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Grid de opciones (Tarjetas Acrílicas)
          Padding(
            padding: const EdgeInsets.only(top: 250.0),
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 1,
              ),
              itemCount: options.length,
              itemBuilder: (context, index) {
                final opt = options[index];
                return ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: Colors.white.withOpacity(0.3),
                        border: Border.all(color: Colors.white.withOpacity(0.1), width: 0.8),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => opt.onTap(context),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: opt.color.withOpacity(0.4),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(opt.icon, size: 40, color: opt.color),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                opt.label,
                                textAlign: TextAlign.center,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).textTheme.bodyMedium?.color,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white.withOpacity(0.3),
        selectedItemColor: Theme.of(context).colorScheme.primary,
        unselectedItemColor: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.6),
        showSelectedLabels: false,
        showUnselectedLabels: false,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.widgets),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Reports',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class _MenuOption {
  final IconData icon;
  final String label;
  final Color color;
  final void Function(BuildContext) onTap;
  _MenuOption({required this.icon, required this.label, required this.onTap, required this.color});
}