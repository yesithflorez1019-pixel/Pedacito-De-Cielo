// lib/producto_detalle_page.dart
import 'dart:io';
import 'dart:ui'; // Importado para usar ImageFilter (efecto blur)
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'database.dart';
import 'formato.dart';
import 'insumo.dart';
import 'producto.dart';

// --- Paleta de Colores ---
const Color kColorHeader1 = Color(0xFFE3AADD);
const Color kColorHeader2 = Color(0xFFC8A8E9);
const Color kColorPrimary = Color(0xFFEB8DB5);
const Color kColorTextDark = Color(0xFF333333);
const Color kColorBackground1 = Color(0xFFFCFAF2);
const Color kColorBackground2 = Color(0xFFF6BCBA);

class FacturaFoto {
  int? id;
  String nombre;
  final String path;

  FacturaFoto({this.id, required this.nombre, required this.path});
}

class ProductoDetallePage extends StatefulWidget {
  final Producto producto;
  const ProductoDetallePage({super.key, required this.producto});

  @override
  State<ProductoDetallePage> createState() => _ProductoDetallePageState();
}

class _ProductoDetallePageState extends State<ProductoDetallePage> {
  // Estado para la pestaña de Receta/Insumos
  late Producto _productoActual;
  List<Map<String, dynamic>> _insumosAsignados = [];
  double _costoTotalTanda = 0.0;
  late TextEditingController _rendimientoCtrl;

  // Estado para la pestaña de Facturas
  List<FacturaFoto> _facturas = [];

  @override
  void initState() {
    super.initState();
    _productoActual = widget.producto;
    _rendimientoCtrl = TextEditingController(text: _productoActual.rendimientoTanda.toString());
    _rendimientoCtrl.addListener(() => setState(() {}));
    _cargarDatos();
  }

  @override
  void dispose() {
    _rendimientoCtrl.dispose();
    super.dispose();
  }

  Future<void> _cargarDatos() async {
    await _cargarInsumos();
    await _cargarFacturas();
  }

  Future<void> _cargarInsumos() async {
    final data = await AppDatabase.obtenerInsumosDeProducto(_productoActual.id!);
    double costoCalculado = 0;
    for (var insumo in data) {
      final precio = (insumo['precio'] as num?)?.toDouble() ?? 0.0;
      final cantidad = (insumo['cantidad'] as num?)?.toDouble() ?? 0.0;
      costoCalculado += precio * cantidad;
    }
    if (!mounted) return;
    setState(() {
      _insumosAsignados = data;
      _costoTotalTanda = costoCalculado;
    });
  }

  Future<void> _cargarFacturas() async {
    final lista = await AppDatabase.obtenerFacturasDeProducto(_productoActual.id!);
    if (!mounted) return;
    setState(() {
      _facturas = lista
          .map((map) => FacturaFoto(
                id: map['id'] as int,
                nombre: map['nombre'] as String,
                path: map['path'] as String,
              ))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, true);
        return true;
      },
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [kColorBackground1, kColorBackground2],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: DefaultTabController(
            length: 2,
            child: Column(
              children: [
                // 1. Encabezado con bordes inferiores redondeados
                Container(
                  padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
                  decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [kColorHeader1, kColorHeader2],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))
                      ]),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 4.0, right: 16.0),
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 20),
                              onPressed: () => Navigator.pop(context, true),
                            ),
                            Expanded(
                              child: Text(
                                _productoActual.nombre,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const TabBar(
                        indicatorColor: Colors.white,
                        labelColor: Colors.white,
                        unselectedLabelColor: Colors.white70,
                        indicatorWeight: 2.5,
                        tabs: [
                          Tab(icon: Icon(Icons.receipt_long_outlined), text: 'Receta'),
                          Tab(icon: Icon(Icons.photo_library_outlined), text: 'Facturas'),
                        ],
                      ),
                    ],
                  ),
                ),
                // 2. Contenido de las pestañas
                Expanded(
                  child: TabBarView(
                    children: [
                      _buildRecetaView(),
                      _buildFacturasView(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRecetaView() {
    final rendimiento = int.tryParse(_rendimientoCtrl.text) ?? 1;
    final costoPorUnidad = (rendimiento > 0) ? _costoTotalTanda / rendimiento : 0.0;

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.fromLTRB(8, 16, 8, 90),
          children: [
            AcrylicCard(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    _buildInfoRow(
                        "Costo Tanda:",
                        _costoTotalTanda.aPesos(),
                        const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16, color: kColorTextDark)),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _rendimientoCtrl,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(color: kColorTextDark),
                      decoration: InputDecoration(
                        labelText: 'Rendimiento (unidades)',
                        prefixIcon: const Icon(Icons.bakery_dining_outlined, color: kColorPrimary),
                        fillColor: Colors.white.withOpacity(0.5),
                      ),
                    ),
                    const Divider(height: 30, color: kColorPrimary, indent: 20, endIndent: 20),
                    _buildInfoRow(
                        "Costo por Unidad:",
                        costoPorUnidad.aPesos(),
                        Theme.of(context)
                            .textTheme
                            .headlineSmall
                            ?.copyWith(color: kColorPrimary, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.save_outlined),
                        onPressed: _guardarRendimiento,
                        label: const Text('Guardar Rendimiento'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kColorPrimary,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            ..._insumosAsignados.map((insumo) {
              return AcrylicCard(
                child: ListTile(
                  leading: const Icon(Icons.blender_outlined, color: kColorPrimary),
                  title: Text(insumo['nombre'],
                      style: const TextStyle(fontWeight: FontWeight.w600, color: kColorTextDark)),
                  subtitle: Text('${insumo['cantidad']} ${insumo['unidad']}',
                      style: TextStyle(color: kColorTextDark.withOpacity(0.7))),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                    onPressed: () async {
                      await AppDatabase.eliminarProductoInsumo(_productoActual.id!, insumo['id']);
                      _cargarInsumos();
                    },
                  ),
                ),
              );
            }).toList(),
          ],
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: FloatingActionButton.extended(
            onPressed: _mostrarDialogoAgregarInsumo,
            label: const Text('Añadir'),
            icon: const Icon(Icons.add),
            backgroundColor: kColorPrimary,
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value, TextStyle? style) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style:
                Theme.of(context).textTheme.titleMedium?.copyWith(color: kColorTextDark.withOpacity(0.7))),
        Text(value, style: style)
      ],
    );
  }

  Future<void> _guardarRendimiento() async {
    final nuevoRendimiento = int.tryParse(_rendimientoCtrl.text) ?? 1;
    final productoActualizado = _productoActual.copyWith(rendimientoTanda: nuevoRendimiento);
    await AppDatabase.actualizarProducto(productoActualizado);
    setState(() => _productoActual = productoActualizado);
    FocusScope.of(context).unfocus();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Rendimiento guardado.'),
      backgroundColor: kColorPrimary,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(12),
    ));
  }

  Future<void> _mostrarDialogoAgregarInsumo() async {
    final todosLosInsumos = await AppDatabase.getInsumos();
    Insumo? insumoSeleccionado;
    final cantidadCtrl = TextEditingController();

    final guardado = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: kColorBackground1.withOpacity(0.95),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: const Text('Añadir Insumo', style: TextStyle(color: kColorPrimary)),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<Insumo>(
                    value: insumoSeleccionado,
                    hint: const Text('Selecciona un insumo'),
                    items: todosLosInsumos
                        .map((insumo) => DropdownMenuItem(value: insumo, child: Text(insumo.nombre)))
                        .toList(),
                    onChanged: (value) => setDialogState(() => insumoSeleccionado = value),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: cantidadCtrl,
                    decoration: InputDecoration(labelText: 'Cantidad (${insumoSeleccionado?.unidad ?? ''})'),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: Text('Cancelar', style: TextStyle(color: kColorTextDark.withOpacity(0.7))),
                ),
                ElevatedButton(
                  onPressed: (insumoSeleccionado == null)
                      ? null
                      : () async {
                          final cantidad = double.tryParse(cantidadCtrl.text) ?? 0.0;
                          if (cantidad > 0) {
                            await AppDatabase.addInsumoToProducto(
                                _productoActual.id!, insumoSeleccionado!.id!, cantidad);
                            Navigator.pop(context, true);
                          }
                        },
                  style:
                      ElevatedButton.styleFrom(backgroundColor: kColorPrimary, foregroundColor: Colors.white),
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );

    if (guardado == true) _cargarInsumos();
  }

  Widget _buildFacturasView() {
    if (_facturas.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.photo_library_outlined, size: 80, color: kColorPrimary.withOpacity(0.7)),
            const SizedBox(height: 16),
            const Text('Aún no has añadido facturas', style: TextStyle(color: kColorTextDark, fontSize: 16)),
            const SizedBox(height: 8),
            TextButton.icon(
              icon: const Icon(Icons.add_a_photo_outlined),
              label: const Text('Añadir la primera'),
              onPressed: _agregarFotoFactura,
              style: TextButton.styleFrom(foregroundColor: kColorPrimary),
            ),
          ],
        ),
      );
    }
    return Stack(
      children: [
        GridView.builder(
          padding: const EdgeInsets.all(12).copyWith(bottom: 90),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
          ),
          itemCount: _facturas.length,
          itemBuilder: (_, index) {
            final factura = _facturas[index];
            return ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: GridTile(
                footer: GridTileBar(
                  backgroundColor: kColorTextDark.withOpacity(0.7),
                  title: Text(factura.nombre, overflow: TextOverflow.ellipsis),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, size: 20, color: Colors.white),
                    onPressed: () => _eliminarFactura(factura, index),
                  ),
                ),
                child: Image.file(File(factura.path), fit: BoxFit.cover),
              ),
            );
          },
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: FloatingActionButton(
            onPressed: _agregarFotoFactura,
            backgroundColor: kColorPrimary,
            foregroundColor: Colors.white,
            child: const Icon(Icons.add_a_photo),
          ),
        ),
      ],
    );
  }

  Future<void> _agregarFotoFactura() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile == null) return;

    final directory = await getApplicationDocumentsDirectory();
    final newPath = '${directory.path}/${DateTime.now().millisecondsSinceEpoch}.jpg';
    await File(pickedFile.path).copy(newPath);

    final nombreCtrl = TextEditingController();
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kColorBackground1.withOpacity(0.95),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("Nombre de la factura", style: TextStyle(color: kColorPrimary)),
        content:
            TextFormField(controller: nombreCtrl, decoration: const InputDecoration(hintText: "Ej: El Panadero")),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text("Cancelar", style: TextStyle(color: kColorTextDark.withOpacity(0.7)))),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            style: ElevatedButton.styleFrom(backgroundColor: kColorPrimary, foregroundColor: Colors.white),
            child: const Text("Guardar"),
          ),
        ],
      ),
    );

    await AppDatabase.insertarFactura(
        _productoActual.id!, nombreCtrl.text.isNotEmpty ? nombreCtrl.text : "Sin nombre", newPath);
    await _cargarFacturas();
  }

  void _eliminarFactura(FacturaFoto factura, int index) async {
    final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              backgroundColor: kColorBackground1.withOpacity(0.95),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: const Text("Confirmar eliminación"),
              content: Text("¿Deseas eliminar la factura '${factura.nombre}'?"),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: Text("Cancelar", style: TextStyle(color: kColorTextDark.withOpacity(0.7)))),
                ElevatedButton(
                  onPressed: () async => Navigator.pop(ctx, true),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
                  child: const Text("Eliminar"),
                ),
              ],
            ));

    if (confirmed == true) {
      await AppDatabase.eliminarFactura(factura.id!);
      setState(() => _facturas.removeAt(index));
    }
  }
}

// --- WIDGETS DE DISEÑO REUTILIZABLES ---

// Widget para el efecto Acrílico / Vidrio Esmerilado
class AcrylicCard extends StatelessWidget {
  final Widget child;
  const AcrylicCard({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.white.withOpacity(0.3),
              border: Border.all(color: Colors.white.withOpacity(0.1), width: 0.8),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}