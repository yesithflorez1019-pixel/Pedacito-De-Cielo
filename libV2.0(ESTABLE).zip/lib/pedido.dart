// pedido.dart

import 'detalle_pedido.dart';
import 'formato.dart'; // <-- extensión num.aPesos()

class Pedido {
  final int? id;                 // id del pedido, opcional antes de guardar
  final int tandaId;             // id de la tanda
  final String cliente;
  final String direccion;
  final bool entregado;
  final bool pagado;
  final double pagoParcial;
  final List<DetallePedido> detalles;
  final String? nombreTanda;      // <-- NUEVO: nombre de la tanda

  Pedido({
    this.id,
    required this.tandaId,
    required this.cliente,
    required this.direccion,
    this.entregado = false,
    this.pagado = false,
    this.pagoParcial = 0.0,
    List<DetallePedido>? detalles,
    this.nombreTanda,              // <-- se recibe en el constructor
  }) : detalles = detalles ?? [];

  /// Total real del pedido (para cálculos internos)
  double get total => detalles.fold(0.0, (a, d) => a + d.subtotal);

  /// Total pendiente de pago
  double get totalPendiente => (total - pagoParcial).clamp(0, total);

  /// Total formateado como pesos
  String get totalFormateado => total.aPesos();

  /// Pago parcial formateado como pesos
  String get pagoParcialFormateado => pagoParcial.aPesos();

  /// Falta por pagar formateado como pesos
  String get restanteFormateado => totalPendiente.aPesos();
}
