// lib/inventario_page.dart
import 'package:flutter/material.dart';
import 'insumos_page.dart';
import 'ver_productos.dart';

// --- Paleta de Colores ---
const Color kColorHeader1 = Color(0xFFE3AADD);
const Color kColorHeader2 = Color(0xFFC8A8E9);
const Color kColorBackground1 = Color(0xFFFCFAF2);
const Color kColorBackground2 = Color(0xFFF6BCBA);

class InventarioPage extends StatelessWidget {
  const InventarioPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        // Usamos un AppBar personalizado para unificar todo
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(120.0), // Altura para título y pestañas
          child: Container(
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [kColorHeader1, kColorHeader2],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 10,
                  offset: Offset(0, 4),
                )
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 8),
                const Text(
                  "Centro de Inventario",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const TabBar(
                  indicatorColor: Colors.white,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white70,
                  indicatorWeight: 2.5,
                  tabs: [
                    Tab(icon: Icon(Icons.blender_outlined), text: 'Insumos'),
                    Tab(icon: Icon(Icons.cake_outlined), text: 'Productos'),
                  ],
                ),
              ],
            ),
          ),
        ),
        // El cuerpo es el TabBarView dentro de nuestro fondo degradado
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [kColorBackground1, kColorBackground2],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const TabBarView(
            children: [
              InsumosPage(),
              VerProductosPage(esSubPagina: true),
            ],
          ),
        ),
      ),
    );
  }
}