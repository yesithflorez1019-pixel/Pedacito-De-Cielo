import 'producto.dart';
import 'formato.dart'; // <-- extensión num.aPesos()

class DetallePedido {
  final int? id;         // id único del detalle
  int? pedidoId;          // <-- puede ser nulo antes de guardar el pedido
  final Producto producto;
  int cantidad;           // mutable porque puede cambiar en edición

  DetallePedido({
    this.id,
    this.pedidoId,
    required this.producto,
    required this.cantidad,
  });

  double get subtotal => producto.precio * cantidad.toDouble();

  Map<String, dynamic> toMap() => {
        'id': id,
        'pedidoId': pedidoId,
        'productoId': producto.id,
        'cantidad': cantidad,
      };

  factory DetallePedido.fromMap(Map<String, dynamic> map, Producto producto) {
    return DetallePedido(
      id: map['id'] as int?,
      pedidoId: map['pedidoId'] as int?,  // asegurar compatibilidad con null
      producto: producto,
      cantidad: map['cantidad'] as int,
    );
  }

  @override
  String toString() => '${producto.nombre} x$cantidad — ${subtotal.aPesos()}';
}
