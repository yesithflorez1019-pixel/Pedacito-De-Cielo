import 'dart:ui';
import 'package:flutter/material.dart';
import 'database.dart';
import 'insumo.dart';
import 'formato.dart';

class InsumosPage extends StatefulWidget {
  const InsumosPage({super.key});

  @override
  State<InsumosPage> createState() => _InsumosPageState();
}

class _InsumosPageState extends State<InsumosPage> {
  List<Insumo> _insumos = [];

  @override
  void initState() {
    super.initState();
    _cargarInsumos();
  }

  Future<void> _cargarInsumos() async {
    final data = await AppDatabase.getInsumos();
    setState(() {
      _insumos = data;
    });
  }

  Future<void> _mostrarDialogoInsumo({Insumo? insumo}) async {
    final esNuevo = insumo == null;
    final nombreCtrl = TextEditingController(text: insumo?.nombre ?? '');
    final precioTotalCtrl = TextEditingController();
    final cantidadCompradaCtrl = TextEditingController();
    
    String unidadSeleccionada = insumo?.unidad ?? 'g';
    double costoCalculado = insumo?.precio ?? 0.0;
    final precioUnitarioCtrl = TextEditingController(text: insumo?.precio.toString() ?? '');

    final guardado = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            void calcularCosto() {
              final precioTotal = double.tryParse(precioTotalCtrl.text) ?? 0.0;
              final cantidadTotal = double.tryParse(cantidadCompradaCtrl.text) ?? 0.0;
              if (cantidadTotal > 0) {
                setDialogState(() {
                  costoCalculado = precioTotal / cantidadTotal;
                  precioUnitarioCtrl.text = costoCalculado.toStringAsFixed(2);
                });
              }
            }

            return AlertDialog(
              backgroundColor: Theme.of(context).colorScheme.surface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: Text(esNuevo ? 'Nuevo Insumo' : 'Actualizar Costo', style: Theme.of(context).textTheme.titleLarge),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextFormField(
                      controller: nombreCtrl,
                      decoration: const InputDecoration(labelText: 'Nombre del Insumo', prefixIcon: Icon(Icons.label)),
                    ),
                    const SizedBox(height: 16),
                    Text('Calcular Costo por Unidad (Opcional)', style: Theme.of(context).textTheme.titleSmall),
                    const Divider(),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: precioTotalCtrl,
                            onChanged: (_) => calcularCosto(),
                            decoration: const InputDecoration(labelText: 'Precio del Paquete', prefixText: '\$ '),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: TextFormField(
                            controller: cantidadCompradaCtrl,
                            onChanged: (_) => calcularCosto(),
                            decoration: const InputDecoration(labelText: 'Cantidad'),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text('Unidad de Medida', style: Theme.of(context).textTheme.bodySmall),
                    DropdownButton<String>(
                      value: unidadSeleccionada,
                      isExpanded: true,
                      dropdownColor: Theme.of(context).colorScheme.surface,
                      items: const [
                        DropdownMenuItem(value: 'g', child: Text('Gramos (g)')),
                        DropdownMenuItem(value: 'ml', child: Text('Mililitros (ml)')),
                        DropdownMenuItem(value: 'unidad', child: Text('Unidad (u)')),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() => unidadSeleccionada = value);
                        }
                      },
                    ),
                    const Divider(),
                    TextFormField(
                      controller: precioUnitarioCtrl,
                      decoration: InputDecoration(
                        labelText: 'Costo Final por Unidad (\$ / $unidadSeleccionada)',
                        fillColor: Theme.of(context).colorScheme.background,
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
                ElevatedButton(
                  onPressed: () async {
                    final nombre = nombreCtrl.text.trim();
                    final precioFinal = double.tryParse(precioUnitarioCtrl.text) ?? 0.0;
                    
                    if (nombre.isNotEmpty && precioFinal > 0) {
                      final nuevoInsumo = Insumo(
                        id: insumo?.id,
                        nombre: nombre,
                        precio: precioFinal,
                        unidad: unidadSeleccionada,
                      );
                      if (esNuevo) {
                        await AppDatabase.insertarInsumo(nuevoInsumo);
                      } else {
                        // TODO: Crear AppDatabase.actualizarInsumo(nuevoInsumo);
                      }
                      Navigator.pop(context, true);
                    }
                  },
                  child: const Text('Guardar'),
                  style: ElevatedButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.primary),
                ),
              ],
            );
          },
        );
      },
    );

    if (guardado == true) {
      _cargarInsumos();
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color colorHeader1 = const Color(0xFFE3AADD);
    final Color colorHeader2 = const Color(0xFFD4A3C4);
    final Color colorFondoClaro = const Color(0xFFFCFAF2);
    final Color colorFondoOscuro = const Color(0xFFF6BCBA);
    final Color colorTextoOscuro = Theme.of(context).textTheme.bodyMedium?.color ?? Colors.black87;
    final Color colorPrimario = Theme.of(context).colorScheme.primary;

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [colorFondoClaro, colorFondoOscuro],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          ClipPath(
            clipper: HeaderClipper(),
            child: Container(
              height: 250,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [colorHeader1, colorHeader2],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Positioned(
            top: 50,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 20),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Gestión de Insumos',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.refresh, color: Colors.white),
                    onPressed: _cargarInsumos,
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 150.0),
            child: _insumos.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.inventory_2_outlined, size: 80, color: colorTextoOscuro.withOpacity(0.3)),
                        const SizedBox(height: 16),
                        Text('No hay insumos', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: colorTextoOscuro.withOpacity(0.6))),
                        const SizedBox(height: 8),
                        Text('Agrega tu materia prima aquí.', style: TextStyle(color: colorTextoOscuro.withOpacity(0.5), fontSize: 16)),
                      ],
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _cargarInsumos,
                    child: ListView.builder(
                      padding: const EdgeInsets.only(top: 8, bottom: 90),
                      itemCount: _insumos.length,
                      itemBuilder: (context, index) {
                        final insumo = _insumos[index];
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(16),
                                  color: const Color.fromARGB(255, 20, 20, 20).withOpacity(0.3),
                                  border: Border.all(color: Colors.white.withOpacity(0.1), width: 0.8),
                                ),
                                child: ListTile(
                                  leading: CircleAvatar(
                                    backgroundColor: colorPrimario.withOpacity(0.2),
                                    child: Icon(Icons.blender_outlined, color: Colors.white),
                                  ),
                                  title: Text(insumo.nombre, style: Theme.of(context).textTheme.titleLarge?.copyWith(color: colorTextoOscuro)),
                                  subtitle: Text('Costo: ${insumo.precio.aPesos()} / ${insumo.unidad}', style: TextStyle(color: colorTextoOscuro.withOpacity(0.7))),
                                  trailing: IconButton(
                                    icon: const Icon(Icons.edit_outlined, color: Colors.white),
                                    onPressed: () => _mostrarDialogoInsumo(insumo: insumo),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _mostrarDialogoInsumo(),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class HeaderClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height);
    var firstControlPoint = Offset(size.width * 0.25, size.height);
    var firstEndPoint = Offset(size.width * 0.5, size.height - 30);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy, firstEndPoint.dx, firstEndPoint.dy);
    var secondControlPoint = Offset(size.width * 0.75, size.height - 60);
    var secondEndPoint = Offset(size.width, size.height - 40);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy, secondEndPoint.dx, secondEndPoint.dy);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}