// lib/insumo.dart
class Insumo {
  final int? id;
  final String nombre;
  final String unidad; // Ej: "g", "ml", "unidad"
  final double precio; // Costo por unidad de medida

  const Insumo({
    this.id,
    required this.nombre,
    required this.unidad,
    required this.precio,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'nombre': nombre,
      'unidad': unidad,
      'precio': precio,
    };
  }

  factory Insumo.fromMap(Map<String, dynamic> map) {
    return Insumo(
      id: map['id'] as int?,
      nombre: map['nombre'] as String,
      unidad: map['unidad'] as String,
      precio: (map['precio'] as num).toDouble(),
    );
  }
}