import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import 'database.dart';
import 'producto.dart';
import 'insumo.dart';

class FacturaFoto {
  int? id;
  String nombre;
  final String path;

  FacturaFoto({this.id, required this.nombre, required this.path});
}

class ProductoDetallePage extends StatefulWidget {
  final Producto producto;

  const ProductoDetallePage({super.key, required this.producto});

  @override
  State<ProductoDetallePage> createState() => _ProductoDetallePageState();
}

class _ProductoDetallePageState extends State<ProductoDetallePage> {
  List<Map<String, dynamic>> insumosAsignados = [];
  List<FacturaFoto> facturas = [];

  @override
  void initState() {
    super.initState();
    cargarInsumos();
    cargarFacturas();
  }

  // ================== INSUMOS ==================
  void _editarInsumo(Map<String, dynamic> insumo) async {
  final cantidadCtrl =
      TextEditingController(text: insumo['cantidad'].toString());
  String unidadSeleccionada = insumo['unidad'] ?? "g";

  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text("Editar Insumo"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(insumo['nombre'], style: const TextStyle(fontWeight: FontWeight.bold)),
          TextField(
            controller: cantidadCtrl,
            decoration: const InputDecoration(labelText: "Cantidad"),
            keyboardType: TextInputType.number,
          ),
          DropdownButtonFormField<String>(
            value: unidadSeleccionada,
            items: const [
              DropdownMenuItem(value: "g", child: Text("Gramos")),
              DropdownMenuItem(value: "lb", child: Text("Libras")),
              DropdownMenuItem(value: "L", child: Text("Litros")),
            ],
            onChanged: (value) {
              unidadSeleccionada = value!;
            },
            decoration: const InputDecoration(labelText: "Unidad"),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text("Cancelar"),
        ),
        ElevatedButton(
          onPressed: () async {
            await AppDatabase.actualizarCantidadInsumo(
              widget.producto.id!,
              insumo['id'],
              double.tryParse(cantidadCtrl.text) ?? 0,
            );
            Navigator.pop(ctx);
            await cargarInsumos();
          },
          child: const Text("Guardar"),
        ),
      ],
    ),
  );
}

  Future<void> cargarInsumos() async {
    insumosAsignados =
        await AppDatabase.obtenerInsumosDeProducto(widget.producto.id!);
    if (mounted) setState(() {});
  }

  void _asignarInsumoManual() async {
    final nombreCtrl = TextEditingController();
    final cantidadCtrl = TextEditingController();
    final precioCtrl = TextEditingController();
    String? unidadSeleccionada;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Agregar Insumo Manual"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nombreCtrl,
                decoration:
                    const InputDecoration(labelText: "Nombre del insumo"),
              ),
              TextField(
                controller: cantidadCtrl,
                decoration: const InputDecoration(labelText: "Cantidad"),
                keyboardType: TextInputType.number,
              ),
              DropdownButtonFormField<String>(
                value: unidadSeleccionada,
                items: const [
                  DropdownMenuItem(value: "g", child: Text("Gramos")),
                  DropdownMenuItem(value: "lb", child: Text("Libras")),
                  DropdownMenuItem(value: "L", child: Text("Litros")),
                ],
                onChanged: (value) {
                  unidadSeleccionada = value;
                },
                decoration: const InputDecoration(labelText: "Unidad"),
              ),
              TextField(
                controller: precioCtrl,
                decoration: const InputDecoration(labelText: "Precio"),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Cancelar"),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nombreCtrl.text.isNotEmpty &&
                  cantidadCtrl.text.isNotEmpty &&
                  unidadSeleccionada != null &&
                  precioCtrl.text.isNotEmpty) {
                final insumo = Insumo(
                  nombre: nombreCtrl.text,
                  unidad: unidadSeleccionada!,
                  precio: double.tryParse(precioCtrl.text) ?? 0,
                );

                final idInsumo = await AppDatabase.insertarInsumo(insumo);

                await AppDatabase.addInsumoToProducto(
                  widget.producto.id!,
                  idInsumo,
                  double.tryParse(cantidadCtrl.text) ?? 0,
                );

                if (!mounted) return;
                Navigator.pop(ctx);
                await cargarInsumos();
              }
            },
            child: const Text("Guardar"),
          ),
        ],
      ),
    );
  }

  // ================== FACTURAS ==================
  Future<void> cargarFacturas() async {
    final lista =
        await AppDatabase.obtenerFacturasDeProducto(widget.producto.id!);
    setState(() {
      facturas = lista
          .map((map) => FacturaFoto(
                id: map['id'] as int,
                nombre: map['nombre'] as String,
                path: map['path'] as String,
              ))
          .toList();
    });
  }

  Future<void> _agregarFotoFactura() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);

    if (pickedFile == null) return;

    final directory = await getApplicationDocumentsDirectory();
    final newPath =
        '${directory.path}/${DateTime.now().millisecondsSinceEpoch}.jpg';
    await File(pickedFile.path).copy(newPath);

    final nombreCtrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Nombre de la factura"),
        content: TextField(
          controller: nombreCtrl,
          decoration: const InputDecoration(hintText: "Ej: El Panadero"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Cancelar"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Guardar"),
          ),
        ],
      ),
    );

    final id = await AppDatabase.insertarFactura(
        widget.producto.id!, nombreCtrl.text.isNotEmpty ? nombreCtrl.text : "Sin nombre", newPath);

    final factura = FacturaFoto(
      id: id,
      nombre: nombreCtrl.text.isNotEmpty ? nombreCtrl.text : "Sin nombre",
      path: newPath,
    );

    setState(() {
      facturas.add(factura);
    });
  }

  void _mostrarOpcionesAgregarInsumo() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Agregar"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text("Ingresar insumo manual"),
              onPressed: () {
                Navigator.pop(ctx);
                _asignarInsumoManual();
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.camera_alt),
              label: const Text("Agregar foto de factura"),
              onPressed: () async {
                Navigator.pop(ctx);
                await _agregarFotoFactura();
              },
            ),
          ],
        ),
      ),
    );
  }

  // ================== UI ==================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detalle: ${widget.producto.nombre}"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ====== INSUMOS ======
              const Text(
                "Insumos",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              insumosAsignados.isEmpty
                  ? const Text("No hay insumos")
                  : ListView.builder(
  shrinkWrap: true,
  physics: const NeverScrollableScrollPhysics(),
  itemCount: insumosAsignados.length,
  itemBuilder: (_, i) {
    final insumo = insumosAsignados[i];
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      child: ListTile(
        title: Text(insumo['nombre']),
        subtitle: Text("Cantidad: ${insumo['cantidad']} ${insumo['unidad']}"),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Botón editar
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () => _editarInsumo(insumo),
            ),
            // Botón eliminar con confirmación
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text("Confirmar eliminación"),
                    content: Text(
                        "¿Seguro que deseas eliminar el insumo '${insumo['nombre']}'?"),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text("Cancelar"),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await AppDatabase.eliminarProductoInsumo(
                              widget.producto.id!, insumo['id']);
                          await cargarInsumos();
                        },
                        child: const Text("Eliminar"),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  },
),

              const SizedBox(height: 20),
              // ====== FACTURAS ======
              const Text(
                "Facturas",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              facturas.isEmpty
                  ? const Text("No hay facturas")
                  : SizedBox(
                      height: 200,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: facturas.length,
                        itemBuilder: (_, index) {
                          final factura = facturas[index];
                          return Padding(
                            padding: const EdgeInsets.only(right: 12),
                            child: GestureDetector(
                              onTap: () async {
                                await Navigator.push(context,
                                    MaterialPageRoute(builder: (_) {
                                  return Scaffold(
                                    appBar: AppBar(
                                        title: Text(factura.nombre),
                                        backgroundColor: Colors.pinkAccent),
                                    body: Center(
                                      child: GestureDetector(
                                        onTap: () async {
                                          final nombreCtrl =
                                              TextEditingController(
                                                  text: factura.nombre);
                                          await showDialog(
                                              context: context,
                                              builder: (ctx) => AlertDialog(
                                                    title: const Text(
                                                        "Editar nombre"),
                                                    content: TextField(
                                                        controller: nombreCtrl),
                                                    actions: [
                                                      TextButton(
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                  ctx),
                                                          child: const Text(
                                                              "Cancelar")),
                                                      ElevatedButton(
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                  ctx),
                                                          child: const Text(
                                                              "Guardar")),
                                                    ],
                                                  ));
                                          if (nombreCtrl.text.isNotEmpty &&
                                              nombreCtrl.text !=
                                                  factura.nombre) {
                                            await AppDatabase
                                                .actualizarNombreFactura(
                                                    factura.id!,
                                                    nombreCtrl.text);
                                            setState(() {
                                              factura.nombre =
                                                  nombreCtrl.text;
                                            });
                                          }
                                        },
                                        child: Image.file(
                                          File(factura.path),
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                  );
                                }));
                              },
                              child: Stack(
                                children: [
                                  Card(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    elevation: 5,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(16),
                                      child: Image.file(
                                        File(factura.path),
                                        width: 140,
                                        height: 180,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 8,
                                    left: 8,
                                    right: 8,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 4, horizontal: 6),
                                      decoration: BoxDecoration(
                                          color: Colors.black54,
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      child: Text(
                                        factura.nombre,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 8,
                                    right: 8,
                                    child: GestureDetector(
                                     onTap: () {
                                        showDialog(
                                          context: context,
                                          builder: (ctx) => AlertDialog(
                                            title: const Text("Confirmar eliminación"),
                                            content: Text("¿Deseas eliminar la factura '${factura.nombre}'?"),
                                            actions: [
                                              TextButton(
                                                onPressed: () => Navigator.pop(ctx),
                                                child: const Text("Cancelar"),
                                              ),
                                              ElevatedButton(
                                                onPressed: () async {
                                                  Navigator.pop(ctx);
                                                  await AppDatabase.eliminarFactura(factura.id!);
                                                  setState(() {
                                                    facturas.removeAt(index);
                                                  });
                                                },
                                                child: const Text("Eliminar"),
                                              ),
                                            ],
                                          ),
                                        );
                                      },

                                      child: const CircleAvatar(
                                        backgroundColor: Colors.red,
                                        radius: 14,
                                        child: Icon(Icons.delete,
                                            color: Colors.white, size: 18),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.pinkAccent,
        onPressed: _mostrarOpcionesAgregarInsumo,
        child: const Icon(Icons.add),
      ),
    );
  }
}
