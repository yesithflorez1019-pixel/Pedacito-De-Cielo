class Producto {
  final int? id;
  final String nombre;
  final double precio;

  const Producto({
    this.id,
    required this.nombre,
    required this.precio,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'nombre': nombre,
        'precio': precio,
      };

  factory Producto.fromMap(Map<String, dynamic> map) => Producto(
        id: map['id'] as int?,
        nombre: map['nombre'] as String,
        precio: (map['precio'] as num).toDouble(),
      );
}
