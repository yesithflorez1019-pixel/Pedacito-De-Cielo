import 'package:flutter/material.dart';
import 'database.dart';
import 'tanda.dart';
import 'producto.dart';
import 'ver_pedidos_desde_bd.dart';
import 'informe_ingresos.dart';

class ControlTandasPage extends StatefulWidget {
  const ControlTandasPage({super.key});

  @override
  State<ControlTandasPage> createState() => _ControlTandasPageState();
}

class _ControlTandasPageState extends State<ControlTandasPage> {
  List<Tanda> tandas = [];
  Map<int, int> pedidosCount = {}; // Número de pedidos por tanda

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    final data = await AppDatabase.obtenerTandasConConteo();
    setState(() {
      tandas = data.map((e) => Tanda.fromMap(e)).toList();
      pedidosCount = {
        for (var e in data) e['id'] as int: e['pedidosCount'] as int
      };
    });
  }

  Future<void> crearOEditarTanda({Tanda? tanda}) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => CrearEditarTandaDialog(tanda: tanda),
    );
    if (result == true) await cargar();
  }

  Future<void> eliminar(Tanda tanda) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar tanda'),
        content: const Text(
            '¿Seguro que deseas eliminar esta tanda? Se eliminarán sus pedidos y gastos.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Eliminar')),
        ],
      ),
    );

    if (ok == true && tanda.id != null) {
      await AppDatabase.eliminarTanda(tanda.id!);
      await cargar();
    }
  }

  void abrirTanda(Tanda tanda) async {
    if (tanda.id == null) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TandaHomePage(
          tandaId: tanda.id!,
          nombreTanda: tanda.nombre,
        ),
      ),
    );
    await cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tandas'),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => crearOEditarTanda(),
        backgroundColor: Colors.pinkAccent,
        child: const Icon(Icons.add),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: tandas.length,
          itemBuilder: (context, i) {
            final t = tandas[i];
            final count = pedidosCount[t.id ?? 0] ?? 0;
            return GestureDetector(
              onTap: () => abrirTanda(t),
              child: Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 3,
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          const Icon(Icons.collections_bookmark,
                              size: 32, color: Colors.pinkAccent),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(t.nombre,
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(height: 6),
                                Text('$count pedidos',
                                    style: const TextStyle(
                                        fontSize: 14, color: Colors.black54)),
                              ],
                            ),
                          ),
                          IconButton(
                              icon: const Icon(Icons.edit),
                              onPressed: () => crearOEditarTanda(tanda: t)),
                          IconButton(
                              icon: const Icon(Icons.delete),
                              onPressed: () => eliminar(t)),
                        ],
                      ),
                    ),
                    Positioned(
                      right: 10,
                      top: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.pinkAccent,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text('$count',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class CrearEditarTandaDialog extends StatefulWidget {
  final Tanda? tanda;
  const CrearEditarTandaDialog({super.key, this.tanda});

  @override
  State<CrearEditarTandaDialog> createState() =>
      _CrearEditarTandaDialogState();
}

class _CrearEditarTandaDialogState extends State<CrearEditarTandaDialog> {
  final nombreCtrl = TextEditingController();
  List<Producto> productos = [];
  Map<int, bool> seleccionados = {};
  Map<int, TextEditingController> stockControllers = {};

  @override
  void initState() {
    super.initState();
    if (widget.tanda != null) nombreCtrl.text = widget.tanda!.nombre;
    cargarProductos();
  }

  Future<void> cargarProductos() async {
    final lista = await AppDatabase.obtenerProductos();
    setState(() {
      productos = lista..sort((a, b) => a.nombre.compareTo(b.nombre));
      for (var p in productos) {
        if (p.id != null) {
          seleccionados[p.id!] = false;
          stockControllers[p.id!] = TextEditingController();
        }
      }
    });

    if (widget.tanda?.id != null) {
      final prodTanda =
          await AppDatabase.obtenerProductosDeTanda(widget.tanda!.id!);
      setState(() {
        for (var pt in prodTanda) {
          final pid = pt['productoId'] as int;
          seleccionados[pid] = true;
          stockControllers[pid]?.text = pt['stock'].toString();
        }
      });
    }
  }

  Future<void> guardar() async {
    final nombre = nombreCtrl.text.trim();
    if (nombre.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Debes ingresar un nombre")));
      return;
    }

    int id;
    if (widget.tanda?.id == null) {
      id = await AppDatabase.insertarTanda(Tanda(nombre: nombre));
    } else {
      id = widget.tanda!.id!;
      await AppDatabase.actualizarTanda(Tanda(id: id, nombre: nombre));
      await AppDatabase.limpiarProductosDeTanda(id);
    }

    for (var p in productos) {
      if (p.id != null && seleccionados[p.id!] == true) {
        final stock = int.tryParse(stockControllers[p.id!]?.text ?? '') ?? 0;
        await AppDatabase.asignarProductoATanda(id, p.id!, stock: stock);
      }
    }

    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.tanda == null ? 'Nueva tanda' : 'Editar tanda'),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView(
          shrinkWrap: true,
          children: [
            TextField(
              controller: nombreCtrl,
              decoration: const InputDecoration(hintText: 'Nombre de la tanda'),
            ),
            const SizedBox(height: 12),
            const Text('Selecciona productos y define stock:'),
            const SizedBox(height: 8),
            ...productos.map((p) {
              final id = p.id;
              if (id == null) return Container();
              return Row(
                children: [
                  Checkbox(
                    value: seleccionados[id] ?? false,
                    onChanged: (v) {
                      setState(() {
                        seleccionados[id] = v ?? false;
                        if (v == false) stockControllers[id]?.clear();
                      });
                    },
                  ),
                  Expanded(child: Text(p.nombre)),
                  SizedBox(
                    width: 60,
                    child: TextField(
                      controller: stockControllers[id],
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        hintText: "Stock",
                        isDense: true,
                      ),
                    ),
                  ),
                ],
              );
            }),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar')),
        ElevatedButton(onPressed: guardar, child: const Text('Guardar')),
      ],
    );
  }
}

class TandaHomePage extends StatelessWidget {
  final int tandaId;
  final String nombreTanda;
  const TandaHomePage(
      {super.key, required this.tandaId, required this.nombreTanda});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(nombreTanda),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      body: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        padding: const EdgeInsets.all(16),
        children: [
          _buildOptionCard(
            context,
            icon: Icons.receipt_long,
            label: "Control de pedidos",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => VerPedidosDesdeBDPage(
                      tandaId: tandaId, nombreTanda: nombreTanda),
                ),
              );
            },
          ),
          _buildOptionCard(
            context,
            icon: Icons.bar_chart,
            label: "Informe de ingresos",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => InformeIngresosPage(
                      tandaId: tandaId, nombreTanda: nombreTanda),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildOptionCard(BuildContext context,
      {required IconData icon,
      required String label,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 4,
        color: Colors.white,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 50, color: Colors.pinkAccent),
              const SizedBox(height: 8),
              Text(label,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}
