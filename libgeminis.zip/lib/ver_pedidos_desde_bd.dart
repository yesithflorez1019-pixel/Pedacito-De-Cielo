import 'package:flutter/material.dart';
import 'pedido.dart';
import 'database.dart';
import 'registrar_pedido.dart';
import 'formato.dart'; // <-- extensión num.aPesos()

class VerPedidosDesdeBDPage extends StatefulWidget {
  final int tandaId;
  final String nombreTanda;

  const VerPedidosDesdeBDPage({
    super.key,
    required this.tandaId,
    required this.nombreTanda,
  });

  @override
  State<VerPedidosDesdeBDPage> createState() => _VerPedidosDesdeBDPageState();
}

class _VerPedidosDesdeBDPageState extends State<VerPedidosDesdeBDPage> {
  List<Pedido> listaPedidos = [];
  List<Pedido> pedidosFiltrados = [];

  String filtroBusqueda = '';
  bool? filtroPagado;
  bool? filtroEntregado;

  @override
  void initState() {
    super.initState();
    cargarPedidos();
  }

  Future<void> cargarPedidos() async {
    final pedidos = await AppDatabase.obtenerPedidos(tandaId: widget.tandaId);
    setState(() {
      listaPedidos = pedidos;
      aplicarFiltros();
    });
  }

  void aplicarFiltros() {
    setState(() {
      pedidosFiltrados = listaPedidos.where((pedido) {
        final coincideBusqueda = filtroBusqueda.isEmpty ||
            pedido.cliente.toLowerCase().contains(filtroBusqueda.toLowerCase()) ||
            pedido.detalles.any((detalle) =>
                detalle.producto.nombre.toLowerCase().contains(filtroBusqueda.toLowerCase()));

        final coincidePagado = filtroPagado == null || pedido.pagado == filtroPagado;
        final coincideEntregado = filtroEntregado == null || pedido.entregado == filtroEntregado;

        return coincideBusqueda && coincidePagado && coincideEntregado;
      }).toList();
    });
  }

  Future<void> eliminarPedido(int id) async {
    await AppDatabase.eliminarPedidoPorId(id);
    await cargarPedidos();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Pedido eliminado')),
    );
  }

  void editarPedido(Pedido pedido) async {
    final pedidoEditado = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => RegistrarPedidoPage(
          tandaId: widget.tandaId,
          pedidoEditar: pedido,
        ),
      ),
    );

    if (pedidoEditado != null) {
      await AppDatabase.actualizarPedidoConDetalles(pedidoEditado);
      cargarPedidos();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pedido actualizado')),
      );
    }
  }

  Widget iconoEstado(bool valor, IconData icono, Color color) {
    return Icon(
      icono,
      color: valor ? color : Colors.grey[400],
      size: 22,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF0F5),
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
        title: Text(
          'Pedidos • ${widget.nombreTanda}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            tooltip: "Refrescar",
            onPressed: cargarPedidos,
          ),
        ],
      ),
      body: Column(
        children: [
          // Barra de búsqueda
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Buscar por cliente o producto',
                prefixIcon: const Icon(Icons.search),
                fillColor: Colors.white,
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              ),
              onChanged: (value) {
                filtroBusqueda = value;
                aplicarFiltros();
              },
            ),
          ),
          // Filtros
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                DropdownButton<bool?>(  
                  value: filtroPagado,
                  dropdownColor: Colors.white,
                  hint: const Text('Pagado'),
                  items: const [
                    DropdownMenuItem(value: null, child: Text('Todos')),
                    DropdownMenuItem(value: true, child: Text('Pagados')),
                    DropdownMenuItem(value: false, child: Text('No pagados')),
                  ],
                  onChanged: (value) {
                    filtroPagado = value;
                    aplicarFiltros();
                  },
                ),
                DropdownButton<bool?>(  
                  value: filtroEntregado,
                  dropdownColor: Colors.white,
                  hint: const Text('Entregado'),
                  items: const [
                    DropdownMenuItem(value: null, child: Text('Todos')),
                    DropdownMenuItem(value: true, child: Text('Entregados')),
                    DropdownMenuItem(value: false, child: Text('No entregados')),
                  ],
                  onChanged: (value) {
                    filtroEntregado = value;
                    aplicarFiltros();
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Lista de pedidos
          Expanded(
            child: pedidosFiltrados.isEmpty
                ? const Center(child: Text('No hay pedidos que coincidan'))
                : ListView.builder(
                    itemCount: pedidosFiltrados.length,
                    itemBuilder: (context, index) {
                      final pedido = pedidosFiltrados[index];
                      final total = pedido.total;
                      final pagado = pedido.pagoParcial;
                      final restante = (total - pagado).clamp(0, total);

                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 4,
                        child: ExpansionTile(
                          leading: const Icon(Icons.receipt_long, color: Colors.pinkAccent),
                          title: Text(
                            pedido.cliente,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text('Total: \$${total.aPesos()}'),
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('📍 Dirección: ${pedido.direccion}'),
                                  Text('💸 Total: \$${total.aPesos()}'),
                                  Text('💰 Pago parcial: \$${pagado.aPesos()}'),
                                  Text('❗ Falta por pagar: \$${restante.aPesos()}'),
                                  const SizedBox(height: 6),
                                  const Text('🧁 Detalles:',
                                      style: TextStyle(fontWeight: FontWeight.bold)),
                                  ...pedido.detalles.map((detalle) => Padding(
                                        padding: const EdgeInsets.only(left: 12, top: 2),
                                        child: Text(
                                          '• ${detalle.producto.nombre} x${detalle.cantidad} = \$${detalle.subtotal.aPesos()}',
                                        ),
                                      )),
                                  const SizedBox(height: 12),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.edit, color: Colors.orange),
                                        onPressed: () => editarPedido(pedido),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete, color: Colors.red),
                                        onPressed: () async {
                                          final confirmacion = await showDialog<bool>(
                                            context: context,
                                            builder: (context) => AlertDialog(
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(20),
                                              ),
                                              title: const Text(
                                                '¿Eliminar pedido?',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.pinkAccent,
                                                ),
                                              ),
                                              content: const Text(
                                                'Esta acción no se puede deshacer.\n¿Estás seguro que deseas eliminarlo?',
                                                style: TextStyle(color: Colors.black87),
                                              ),
                                              actionsPadding: const EdgeInsets.symmetric(
                                                  horizontal: 16, vertical: 8),
                                              actions: [
                                                TextButton(
                                                  style: TextButton.styleFrom(
                                                    foregroundColor: Colors.grey[700],
                                                  ),
                                                  onPressed: () => Navigator.pop(context, false),
                                                  child: const Text('Cancelar'),
                                                ),
                                                ElevatedButton(
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor: Colors.pinkAccent,
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                    ),
                                                  ),
                                                  onPressed: () => Navigator.pop(context, true),
                                                  child: const Text('Eliminar'),
                                                ),
                                              ],
                                            ),
                                          );

                                          if (confirmacion == true) {
                                            eliminarPedido(pedido.id!);
                                          }
                                        },
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.pinkAccent,
        child: const Icon(Icons.add),
        onPressed: () async {
          final nuevoPedido = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => RegistrarPedidoPage(tandaId: widget.tandaId),
            ),
          );
          if (!mounted) return;
          if (nuevoPedido != null) {
            cargarPedidos();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Pedido registrado')),
            );
          }
        },
      ),
    );
  }
}
