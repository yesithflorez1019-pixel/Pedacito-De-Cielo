class Insumo {
  final int? id;
  final String nombre;
  final String unidad;
  final double precio;

  const Insumo({
    this.id,
    required this.nombre,
    required this.unidad,
    required this.precio,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'nombre': nombre,
      'unidad': unidad,
      'precio': precio,
    };
  }

  factory Insumo.fromMap(Map<String, dynamic> map) {
    return Insumo(
      id: map['id'] as int?,
      nombre: map['nombre'],
      unidad: map['unidad'],
      precio: map['precio'] is int ? (map['precio'] as int).toDouble() : map['precio'],
    );
  }
}
