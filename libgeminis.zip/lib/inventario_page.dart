import 'package:flutter/material.dart';
import 'database.dart';
import 'producto.dart';
import 'producto_detalle_page.dart';

class InventarioPage extends StatefulWidget {
  const InventarioPage({super.key});

  @override
  State<InventarioPage> createState() => _InventarioPageState();
}

class _InventarioPageState extends State<InventarioPage> {
  List<Producto> productos = [];

  @override
  void initState() {
    super.initState();
    cargarProductos();
  }

  Future<void> cargarProductos() async {
    productos = await AppDatabase.obtenerProductos();
    if (mounted) setState(() {});
  }

 @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: const Text("Inventario"),
      backgroundColor: Colors.pinkAccent,
      foregroundColor: Colors.white,
    ),
    body: productos.isEmpty
        ? const Center(child: Text("No hay productos en el inventario."))
        : ListView.builder(
            itemCount: productos.length,
            itemBuilder: (_, i) {
              final p = productos[i];
              return Card(
                child: ListTile(
                  title: Text(p.nombre),
                  subtitle: Text("Precio: \$${p.precio.toInt()}"),
                  trailing: const Icon(Icons.arrow_forward_ios, color: Colors.pinkAccent),
                  onTap: () {
                    print("CLICK EN INSUMOS DE: ${p.nombre}"); // Debug
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ProductoDetallePage(producto: p),
                      ),
                    );
                  },
                ),
              );
            },
          ),
  );
}

}
