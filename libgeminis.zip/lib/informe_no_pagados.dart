import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'database.dart';
import 'registrar_pedido.dart';

class InformeNoPagadosPage extends StatefulWidget {
  const InformeNoPagadosPage({super.key});

  @override
  State<InformeNoPagadosPage> createState() => _InformeNoPagadosPageState();
}

class _InformeNoPagadosPageState extends State<InformeNoPagadosPage> {
  List<Map<String, dynamic>> clientes = [];
  List<Map<String, dynamic>> clientesFiltrados = [];
  final formatoPesos = NumberFormat.currency(
    locale: 'es_CL',
    symbol: '',
    decimalDigits: 0,
  );
  final searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    searchController.addListener(_filtrarClientes);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _cargarClientes();
  }

  Future<void> _cargarClientes() async {
    final data = await AppDatabase.obtenerClientesDeudores();
    setState(() {
      clientes = data.map((c) => {'cliente': c, 'deuda': 0.0}).toList();
      clientesFiltrados = List.from(clientes);
    });

    // Actualizar la deuda de cada cliente sumando sus pedidos no pagados
    for (var clienteMap in clientes) {
      final pedidos = await AppDatabase.obtenerPedidosNoPagadosPorCliente(clienteMap['cliente']);
      final deudaTotal = pedidos.fold<double>(0.0, (sum, p) => sum + p.totalPendiente);
      clienteMap['deuda'] = deudaTotal;
    }

    setState(() {
      clientesFiltrados = List.from(clientes);
    });
  }

  void _filtrarClientes() {
    final query = searchController.text.toLowerCase();
    setState(() {
      clientesFiltrados = clientes
          .where((c) => (c['cliente'] as String).toLowerCase().contains(query))
          .toList();
    });
  }

  Future<void> _liquidarCliente(String cliente) async {
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        backgroundColor: Colors.pink[50],
        title: const Text("Confirmar", style: TextStyle(color: Colors.pinkAccent)),
        content: Text(
          "¿Estás seguro de liquidar al cliente $cliente?\nEsto marcará sus pedidos como pagados.",
          style: TextStyle(color: Colors.pink[900]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancelar"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.pinkAccent),
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Sí, liquidar"),
          ),
        ],
      ),
    );

    if (confirmado == true) {
      await AppDatabase.liquidarCliente(cliente);
      await _cargarClientes();
    }
  }

  Future<List<Map<String, dynamic>>> _obtenerPedidosCliente(String cliente) async {
    final pedidos = await AppDatabase.obtenerPedidosNoPagadosPorCliente(cliente);

    return Future.wait(pedidos.map((p) async {
      // Obtener nombre de la tanda
      String nombreTanda = '';
      if (p.tandaId != 0) {
        final tanda = await AppDatabase.obtenerTandasConConteo(); // todas las tandas
        final match = tanda.firstWhere(
          (t) => t['id'] == p.tandaId,
          orElse: () => {'nombre': 'Desconocida'},
        );
        nombreTanda = match['nombre'] as String;
      }

      return {
        'objetoPedido': p,            // objeto Pedido real
        'tandaId': p.tandaId,         // id de la tanda
        'tanda': nombreTanda,
        'pendiente': p.totalPendiente,
        'detalles': p.detalles.map((d) => {
          'producto': d.producto.nombre,
          'cantidad': d.cantidad,
          'subtotal': d.subtotal,
        }).toList(),
      };
    }).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Informe No Pagados"),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: searchController,
              decoration: const InputDecoration(
                labelText: 'Buscar cliente',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: clientesFiltrados.isEmpty
                ? const Center(
                    child: Text(
                      "No hay clientes con deudas 🎉",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _cargarClientes,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: clientesFiltrados.length,
                      itemBuilder: (context, i) {
                        final cliente = clientesFiltrados[i]['cliente'];
                        final deuda = (clientesFiltrados[i]['deuda'] as num?)?.toDouble() ?? 0.0;
                        return Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 2,
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          child: ExpansionTile(
                            key: ValueKey(cliente),
                            leading: const Icon(Icons.person, color: Colors.pinkAccent, size: 32),
                            title: Text(cliente, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text("Debe: \$${formatoPesos.format(deuda)}"),
                            trailing: IconButton(
                              icon: const Icon(Icons.check_circle, color: Colors.green),
                              onPressed: () => _liquidarCliente(cliente),
                            ),
                            children: [
                              FutureBuilder<List<Map<String, dynamic>>>(
                                future: _obtenerPedidosCliente(cliente),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState == ConnectionState.waiting) {
                                    return const Padding(
                                      padding: EdgeInsets.all(8),
                                      child: CircularProgressIndicator(),
                                    );
                                  }
                                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                                    return const Padding(
                                      padding: EdgeInsets.all(8.0),
                                      child: Text("No hay pedidos pendientes"),
                                    );
                                  }
                                  final pedidos = snapshot.data!;
                                  return Column(
                                    children: pedidos.map((pedido) {
                                      final detalles = pedido['detalles'] as List<Map<String, dynamic>>;
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4),
                                        child: InkWell(
                                          borderRadius: BorderRadius.circular(12),
                                          onTap: () async {
                                            await Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) => RegistrarPedidoPage(
                                                  pedidoEditar: pedido['objetoPedido'],
                                                  tandaId: pedido['tandaId'],
                                                ),
                                              ),
                                            );
                                            await _cargarClientes();
                                          },
                                          child: Card(
                                            color: Colors.pink[50],
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "Tanda: ${pedido['tanda']} - Pendiente: \$${formatoPesos.format(pedido['pendiente'])}",
                                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                                  ),
                                                  const SizedBox(height: 4),
                                                  ...detalles.map((d) => Text(
                                                      "${d['producto']} x${d['cantidad']} - \$${formatoPesos.format(d['subtotal'])}")),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  );
                                },
                              )
                            ],
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
