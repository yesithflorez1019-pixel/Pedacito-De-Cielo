import 'package:flutter/material.dart';
import 'producto.dart';
import 'pedido.dart';
import 'detalle_pedido.dart';
import 'database.dart';
import 'formato.dart'; // <-- extensión num.aPesos()

class RegistrarPedidoPage extends StatefulWidget {
  final Pedido? pedidoEditar;
  final int tandaId;

  const RegistrarPedidoPage({
    super.key,
    required this.tandaId,
    this.pedidoEditar,
  });

  @override
  State<RegistrarPedidoPage> createState() => _RegistrarPedidoPageState();
}

class _RegistrarPedidoPageState extends State<RegistrarPedidoPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController clienteController = TextEditingController();
  final TextEditingController direccionController = TextEditingController();
  final TextEditingController pagoParcialController = TextEditingController();
  final TextEditingController searchController = TextEditingController();

  List<Map<String, dynamic>> productos = []; // 'producto' + 'stock'
  List<Map<String, dynamic>> productosFiltrados = [];
  List<DetallePedido> detalles = [];
  bool entregado = false;
  bool pagado = false;

  @override
  void initState() {
    super.initState();
    cargarProductos();
    if (widget.pedidoEditar != null) {
      final pedido = widget.pedidoEditar!;
      clienteController.text = pedido.cliente;
      direccionController.text = pedido.direccion;
      pagoParcialController.text = pedido.pagoParcial.toStringAsFixed(0);
      entregado = pedido.entregado;
      pagado = pedido.pagado;
      detalles = List.from(pedido.detalles);
    }
    searchController.addListener(filtrarProductos);
  }

  Future<void> cargarProductos() async {
    final listaMap = await AppDatabase.obtenerProductosDeTanda(widget.tandaId);

    setState(() {
      productos = listaMap.map((map) => {
        'producto': Producto(
          id: map['productoId'] as int,
          nombre: map['nombre'] as String,
          precio: map['precio'] as double,
        ),
        'stock': map['stock'] as int,
      }).toList();
      productosFiltrados = List.from(productos);
    });
  }

  void filtrarProductos() {
    final query = searchController.text.toLowerCase();
    setState(() {
      productosFiltrados = productos
          .where((p) =>
              (p['producto'] as Producto).nombre.toLowerCase().contains(query))
          .toList();
    });
  }

  void agregarDetalle(Producto producto, int cantidad) async {
    final indexProducto =
        productos.indexWhere((p) => (p['producto'] as Producto).id == producto.id);
    if (indexProducto == -1) return;

    final stockDisponible = productos[indexProducto]['stock'] as int;
    final indexDetalle = detalles.indexWhere((d) => d.producto.id == producto.id);
    int cantidadActual = indexDetalle != -1 ? detalles[indexDetalle].cantidad : 0;
    int nuevaCantidad = cantidadActual + cantidad;

    if (nuevaCantidad > stockDisponible) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                'No hay suficiente stock. Stock disponible: $stockDisponible')),
      );
      return;
    }

    setState(() {
      if (indexDetalle != -1) {
        detalles[indexDetalle] =
            DetallePedido(producto: producto, cantidad: nuevaCantidad);
      } else {
        detalles.add(DetallePedido(producto: producto, cantidad: cantidad));
      }

      // Reducimos el stock temporal en la UI
      productos[indexProducto]['stock'] = stockDisponible - cantidad;
    });
  }

 void quitarDetalle(DetallePedido detalle) {
  setState(() {
    detalles.remove(detalle);
    // No modificamos el stock aquí; se ajustará al guardar en la base de datos
  });
}

  double get totalPedido =>
      detalles.fold(0, (suma, det) => suma + det.subtotal);

Future<void> guardarPedido() async {
  if (!_formKey.currentState!.validate()) return;

  if (detalles.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Agrega al menos un producto')),
    );
    return;
  }

  // Calculamos el total del pedido
  final totalPedido = detalles.fold<double>(
    0.0,
    (suma, det) => suma + det.subtotal,
  );

  // Si el pedido se marca como pagado, pagoParcial = total
  final pago = pagado ? totalPedido : double.tryParse(pagoParcialController.text) ?? 0.0;

  final pedido = Pedido(
    id: widget.pedidoEditar?.id,
    tandaId: widget.tandaId,
    cliente: clienteController.text,
    direccion: direccionController.text,
    entregado: entregado,
    pagado: pagado,
    pagoParcial: pago,
    detalles: detalles,
  );

  if (widget.pedidoEditar != null) {
    // === EDITAR PEDIDO ===
    await AppDatabase.actualizarPedidoConDetalles(pedido);
  } else {
    // === NUEVO PEDIDO ===
    await AppDatabase.insertarPedidoConDetalles(pedido);
  }

  if (mounted) Navigator.pop(context, pedido);
}


  void mostrarDialogoCantidad(Producto producto) {
    final indexProducto =
        productos.indexWhere((p) => (p['producto'] as Producto).id == producto.id);
    if (indexProducto == -1) return;

    final stockDisponible = productos[indexProducto]['stock'] as int;
    if (stockDisponible <= 0) return;

    final cantidadController = TextEditingController(text: '1');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Cantidad - ${producto.nombre}'),
        content: TextField(
          controller: cantidadController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
              labelText: 'Cantidad (Stock disponible: $stockDisponible)'),
        ),
        actions: [
          TextButton(
            child: const Text('Cancelar'),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: const Text('Agregar'),
            onPressed: () {
              final cantidad = int.tryParse(cantidadController.text) ?? 1;
              agregarDetalle(producto, cantidad);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.pedidoEditar != null
            ? 'Editar Pedido'
            : 'Registrar Pedido'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: guardarPedido,
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Text(
                'Total: \$${totalPedido.aPesos()}',
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: clienteController,
                decoration: const InputDecoration(
                  labelText: 'Cliente',
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) => value!.isEmpty ? 'Campo requerido' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: direccionController,
                decoration: const InputDecoration(
                  labelText: 'Dirección',
                  prefixIcon: Icon(Icons.location_on),
                ),
                validator: (value) => value!.isEmpty ? 'Campo requerido' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: pagoParcialController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Pago parcial',
                  prefixIcon: Icon(Icons.attach_money),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(Icons.check_circle, color: Colors.green),
                  const SizedBox(width: 8),
                  const Text('Entregado'),
                  Switch(
                    value: entregado,
                    onChanged: (value) => setState(() => entregado = value),
                  ),
                  const SizedBox(width: 20),
                  const Icon(Icons.payment, color: Colors.blue),
                  const SizedBox(width: 8),
                  const Text('Pagado'),
                  Switch(
                    value: pagado,
                    onChanged: (value) => setState(() {
                      pagado = value;
                      if (pagado) {
                        pagoParcialController.text = totalPedido.toString();
                      } else {
                        pagoParcialController.clear();
                      }
                    }),
                  ),
                ],
              ),
              const Divider(),
              TextField(
                controller: searchController,
                decoration: const InputDecoration(
                  labelText: 'Buscar producto',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 150,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: productosFiltrados.length,
                  itemBuilder: (context, index) {
                    final productoMap = productosFiltrados[index];
                    final producto = productoMap['producto'] as Producto;
                    final stock = productoMap['stock'] as int;

                    return Card(
                      child: InkWell(
                        onTap:
                            stock > 0 ? () => mostrarDialogoCantidad(producto) : null,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(producto.nombre,
                                  style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text('\$${producto.precio.aPesos()}'),
                              const SizedBox(height: 4),
                              Text('Stock: $stock',
                                  style: TextStyle(
                                      color: stock > 0 ? Colors.black : Colors.red)),
                              const Icon(Icons.add_shopping_cart),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const Divider(),
              const Text('Detalles del Pedido',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              ...detalles.map((detalle) => ListTile(
                    leading: const Icon(Icons.shopping_cart),
                    title: Text(detalle.producto.nombre),
                    subtitle: Text(
                        'Cantidad: ${detalle.cantidad} - Subtotal: \$${detalle.subtotal.aPesos()}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => quitarDetalle(detalle),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}
