import 'package:flutter/material.dart';
import 'producto.dart';
import 'database.dart';
import 'formato.dart'; // <-- extensión num.aPesos()
import 'package:flutter/services.dart';

class AgregarProductoPage extends StatefulWidget {
  final Producto? productoExistente;
  const AgregarProductoPage({super.key, this.productoExistente});

  @override
  State<AgregarProductoPage> createState() => _AgregarProductoPageState();
}

class _AgregarProductoPageState extends State<AgregarProductoPage> {
  final nombreCtrl = TextEditingController();
  final precioCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.productoExistente != null) {
      nombreCtrl.text = widget.productoExistente!.nombre;
      precioCtrl.text =
          widget.productoExistente!.precio.toInt().aPesos(conSimbolo: false);
    }
  }

  Future<void> guardar() async {
    final nombre = nombreCtrl.text.trim();
    final precio = double.tryParse(precioCtrl.text.replaceAll('.', '')) ?? 0.0;

    if (nombre.isEmpty || precio <= 0) return;

    if (widget.productoExistente != null) {
      // Confirmación antes de actualizar
      final confirmacion = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          backgroundColor: Colors.pink[50],
          title: Text(
            '¡Cuidado!',
            style:
                TextStyle(fontWeight: FontWeight.bold, color: Colors.pinkAccent),
          ),
          content: Text(
            'Actualizar este producto afectará los pedidos existentes.\n¿Seguro que quieres continuar?',
            style: TextStyle(color: Colors.pink[900], fontSize: 16),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pinkAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Actualizar'),
            ),
          ],
        ),
      );

      if (confirmacion != true) return;
    }

    if (widget.productoExistente == null) {
      await AppDatabase.insertarProducto(Producto(nombre: nombre, precio: precio));
    } else {
      await AppDatabase.actualizarProducto(Producto(
        id: widget.productoExistente!.id,
        nombre: nombre,
        precio: precio,
      ));
    }

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final editando = widget.productoExistente != null;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
        title: Text(editando ? 'Editar producto' : 'Nuevo producto'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: nombreCtrl,
              decoration: const InputDecoration(labelText: 'Nombre'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: precioCtrl,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Precio'),
              onChanged: (value) {
                final cleaned = value.replaceAll('.', '');
                if (cleaned.isEmpty) return;
                final numero = int.tryParse(cleaned);
                if (numero == null) return;
                final formatted = numero.aPesos(conSimbolo: false);
                if (formatted != value) {
                  precioCtrl.value = TextEditingValue(
                    text: formatted,
                    selection: TextSelection.collapsed(offset: formatted.length),
                  );
                }
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: guardar,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pinkAccent,
                foregroundColor: Colors.white,
              ),
              child: Text(editando ? 'Actualizar' : 'Guardar'),
            )
          ],
        ),
      ),
    );
  }
}
