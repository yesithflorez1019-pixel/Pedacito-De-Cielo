import 'package:flutter/material.dart';
import 'database.dart';
import 'gasto.dart';
import 'formato.dart'; // <-- extensión num.aPesos()
import 'package:intl/intl.dart';

class InformeIngresosPage extends StatefulWidget {
  final int tandaId;
  final String nombreTanda;
  const InformeIngresosPage({
    super.key,
    required this.tandaId,
    required this.nombreTanda,
  });

  @override
  State<InformeIngresosPage> createState() => _InformeIngresosPageState();
}

class _InformeIngresosPageState extends State<InformeIngresosPage> {
  List<Map<String, dynamic>> ingresos = [];
  List<Gasto> gastos = [];
  double totalPagado = 0.0;
  double totalGastos = 0.0;

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    ingresos = await AppDatabase.obtenerIngresosPorProducto(widget.tandaId);
    totalPagado = await AppDatabase.obtenerTotalPagosParcialesPorTanda(widget.tandaId);
    gastos = await AppDatabase.obtenerGastosPorTanda(widget.tandaId);
    totalGastos = await AppDatabase.obtenerTotalGastosPorTanda(widget.tandaId);

    if (mounted) setState(() {});
  }
  Future<bool?> editarGasto(Gasto gasto) async {
  final descCtrl = TextEditingController(text: gasto.descripcion);
  final montoCtrl = TextEditingController(text: gasto.monto.toString());

  return showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Editar gasto'),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: descCtrl,
            decoration: const InputDecoration(labelText: 'Descripción'),
          ),
          TextField(
            controller: montoCtrl,
            decoration: const InputDecoration(labelText: 'Monto'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancelar'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.pinkAccent),
          onPressed: () async {
            final monto = double.tryParse(montoCtrl.text) ?? 0.0;
            final desc = descCtrl.text.trim();
            if (monto > 0 && desc.isNotEmpty) {
              await AppDatabase.actualizarGasto(Gasto(
                id: gasto.id,
                tandaId: gasto.tandaId,
                descripcion: desc,
                monto: monto,
                fecha: gasto.fecha,
              ));
              Navigator.pop(context, true);
            }
          },
          child: const Text('Guardar'),
        ),
      ],
    ),
  );
}

  Future<void> agregarGasto() async {
    final descCtrl = TextEditingController();
    final montoCtrl = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nuevo gasto'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: descCtrl,
              decoration: const InputDecoration(labelText: 'Descripción'),
            ),
            TextField(
              controller: montoCtrl,
              decoration: const InputDecoration(labelText: 'Monto'),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.pinkAccent,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Guardar'),
          ),
        ],
      ),
    );

    if (ok == true) {
      final monto = double.tryParse(montoCtrl.text) ?? 0.0;
      final desc = descCtrl.text.trim();
      if (monto > 0 && desc.isNotEmpty) {
        await AppDatabase.insertarGasto(
          Gasto(
            tandaId: widget.tandaId,
            descripcion: desc,
            monto: monto,
            fecha: DateTime.now(),
          ),
        );
        await cargar();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final utilidad = totalPagado - totalGastos;
    final formatoFecha = DateFormat('dd/MM/yyyy HH:mm');

    return Scaffold(
      appBar: AppBar(
        title: Text('Ingresos • ${widget.nombreTanda}'),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: agregarGasto,
        backgroundColor: Colors.pinkAccent,
        child: const Icon(Icons.add),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView(
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.attach_money, color: Colors.green),
                title: const Text('Total cobrado (pagado)'),
                trailing: Text('\$${totalPagado.aPesos()}'),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.money_off, color: Colors.red),
                title: const Text('Gastos'),
                trailing: Text('\$${totalGastos.aPesos()}'),
              ),
            ),
            Card(
              child: ListTile(
                leading: Icon(
                  utilidad >= 0 ? Icons.trending_up : Icons.trending_down,
                  color: utilidad >= 0 ? Colors.green : Colors.red,
                ),
                title: const Text('Utilidad'),
                trailing: Text('\$${utilidad.aPesos()}'),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Ingresos por producto',
                style: TextStyle(fontWeight: FontWeight.bold)),
            ...ingresos.map((r) => ListTile(
                  leading: const Icon(Icons.cake),
                  title: Text(r['producto']?.toString() ?? ''),
                  subtitle: Text('Cantidad: ${r['cantidadTotal']}'),
                  trailing: Text(
                    '\$${(r['ingresoTotal'] as double? ?? 0.0).aPesos()}',
                  ),
                )),
            const Divider(),
            const Text('Gastos',
                style: TextStyle(fontWeight: FontWeight.bold)),
                ...gastos.map(
                    (g) => ListTile(
                      leading: const Icon(Icons.receipt_long),
                      title: Text(g.descripcion),
                      subtitle: Text(formatoFecha.format(g.fecha.toLocal())),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Monto
                          Text('\$${g.monto.aPesos()}'),
                          const SizedBox(width: 8),
                          // Botón de editar
                          IconButton(
                            icon: const Icon(Icons.edit, color: Colors.blue),
                            onPressed: () async {
                              final result = await editarGasto(g);
                              if (result == true) await cargar(); // recarga la lista
                            },
                          ),
                          // Botón de eliminar
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () async {
                              final confirm = await showDialog<bool>(
                                context: context,
                                builder: (_) => AlertDialog(
                                  title: const Text('Eliminar gasto'),
                                  content: const Text('¿Deseas eliminar este gasto?'),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(context, false),
                                      child: const Text('Cancelar'),
                                    ),
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.redAccent),
                                      onPressed: () => Navigator.pop(context, true),
                                      child: const Text('Eliminar'),
                                    ),
                                  ],
                                ),
                              );
                              if (confirm == true) {
                                await AppDatabase.eliminarGastoPorId(g.id!);
                                await cargar(); // recarga la lista
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  ),


          ],
        ),
      ),
    );
  }
}
