import 'package:flutter/material.dart';
import 'package:postres_app/inventario_page.dart';
import 'ver_productos.dart';
import 'control_tandas.dart';
import 'informe_no_pagados.dart'; // 👈 importar aquí

void main() {
  runApp(const PedacitoDeCielo());
}

class PedacitoDeCielo extends StatelessWidget {
  const PedacitoDeCielo({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pedacito de Cielo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pinkAccent),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final options = <_MenuOption>[
      _MenuOption(
        icon: Icons.cake,
        label: 'Ver productos',
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const VerProductosPage())),
      ),
      _MenuOption(
        icon: Icons.list_alt,
        label: 'Ver pedidos',
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ControlTandasPage())),
      ),
      _MenuOption(
        icon: Icons.warning_amber_rounded,
        label: 'Informe no pagados', // 👈 Nuevo botón
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const InformeNoPagadosPage())),
      ),
      _MenuOption(
        icon: Icons.warning_amber_rounded,
        label: 'Inventario', // 👈 Nuevo botón
        onTap: (ctx) => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const InventarioPage())),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pedacito de Cielo'),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        children: options.map((opt) => InkWell(
          onTap: () => opt.onTap(context),
          child: Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 2,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(opt.icon, size: 48, color: Colors.pinkAccent),
                  const SizedBox(height: 8),
                  Text(opt.label, style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
        )).toList(),
      ),
    );
  }
}

class _MenuOption {
  final IconData icon;
  final String label;
  final void Function(BuildContext) onTap;
  _MenuOption({required this.icon, required this.label, required this.onTap});
}
