import 'package:flutter/material.dart';
import 'producto.dart';
import 'database.dart';
import 'agregar_producto.dart';
import 'formato.dart'; // <-- usamos aPesos()

class VerProductosPage extends StatefulWidget {
  const VerProductosPage({super.key});

  @override
  State<VerProductosPage> createState() => _VerProductosPageState();
}

class _VerProductosPageState extends State<VerProductosPage> {
  List<Producto> productos = [];

  @override
  void initState() {
    super.initState();
    cargar();
  }

  Future<void> cargar() async {
    productos = await AppDatabase.obtenerProductos();
    if (mounted) setState(() {});
  }

  void editar(Producto p) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => AgregarProductoPage(productoExistente: p)),
    );
    await cargar();
  }

  Future<void> eliminar(int id, String nombreProducto) async {
    final confirmacion = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: Colors.pink[50],
        title: Text(
          '¡Cuidado!',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.pinkAccent,
          ),
        ),
        content: Text(
          'No deberías eliminar "$nombreProducto". '
          'Se pueden perder pedidos e ingresos por falta del producto.',
          style: TextStyle(
            color: Colors.pink[900],
            fontSize: 16,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(
              'Cancelar',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.pinkAccent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );

    if (confirmacion == true) {
      await AppDatabase.eliminarProductoPorId(id);
      await cargar();
    }
  }

  void agregar() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AgregarProductoPage()),
    );
    await cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
        title: const Text('Productos'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: agregar,
        backgroundColor: Colors.pinkAccent,
        child: const Icon(Icons.add),
      ),
      body: productos.isEmpty
          ? const Center(
              child: Text(
                'No hay productos aún.\nToca el + para agregar uno.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            )
          : ListView.builder(
              itemCount: productos.length,
              itemBuilder: (_, i) {
                final p = productos[i];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListTile(
                    title: Text(p.nombre),
                    subtitle: Text(p.precio.toInt().aPesos()), // solo miles
                    leading:
                        const Icon(Icons.cake, color: Colors.pinkAccent),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => editar(p),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () {
                            if (p.id == null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                      'No se puede eliminar: producto sin id.'),
                                ),
                              );
                              return;
                            }
                            eliminar(p.id!, p.nombre);
                          },
                          icon: const Icon(Icons.delete, color: Colors.red),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
