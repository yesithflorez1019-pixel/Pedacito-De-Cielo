import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'producto.dart';
import 'pedido.dart';
import 'detalle_pedido.dart';
import 'gasto.dart';
import 'tanda.dart';
import 'insumo.dart';







class AppDatabase {
  static Future<Database> _getDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'postres.db');

    return openDatabase(
      path,
      version: 9,
      onCreate: (db, version) async {
        await _crearTablas(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await _crearTablas(db);
      },
    );
  }

  static Future<void> _crearTablas(Database db) async {
    await db.execute('''
    CREATE TABLE IF NOT EXISTS facturas(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      productoId INTEGER NOT NULL,
      nombre TEXT NOT NULL,
      path TEXT NOT NULL
    )
  ''');
    await db.execute('''
        CREATE TABLE producto_insumo (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          producto_id INTEGER NOT NULL,
          insumo_id INTEGER NOT NULL,
          cantidad REAL NOT NULL,
          FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE,
          FOREIGN KEY (insumo_id) REFERENCES insumos(id) ON DELETE CASCADE
        )
      ''');

    
    await db.execute('''
        CREATE TABLE insumos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nombre TEXT NOT NULL,
          unidad TEXT,
          precio REAL
        )
        ''');



    await db.execute('''
      CREATE TABLE IF NOT EXISTS productos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        precio REAL
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS tandas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS pedidos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tandaId INTEGER,
        cliente TEXT,
        direccion TEXT,
        entregado INTEGER,
        pagado INTEGER,
        pagoParcial REAL
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS detalles_pedido (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pedidoId INTEGER,
        productoId INTEGER,
        cantidad INTEGER
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS gastos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tandaId INTEGER,
        descripcion TEXT,
        monto REAL,
        fecha TEXT
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS productos_tanda (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tandaId INTEGER,
        productoId INTEGER,
        stock INTEGER NOT NULL DEFAULT 0
      );
    ''');
  }

 // ================== PRODUCTOS ==================
static Future<int> insertarProducto(Producto producto) async {
  final db = await _getDatabase();
  return await db.insert('productos', {
    'nombre': producto.nombre,
    'precio': producto.precio,
  });
}

static Future<void> actualizarProducto(Producto producto) async {
  final db = await _getDatabase();
  await db.update(
    'productos',
    {
      'nombre': producto.nombre,
      'precio': producto.precio,
    },
    where: 'id = ?',
    whereArgs: [producto.id!],
  );
}

static Future<void> eliminarProductoPorId(int id) async {
  final db = await _getDatabase();
  await db.delete('productos', where: 'id = ?', whereArgs: [id]);
}

// ================== OBTENER PRODUCTOS ==================
static Future<List<Producto>> obtenerProductos({int? tandaId}) async {
  final db = await _getDatabase();
  List<Map<String, dynamic>> rows;

  if (tandaId != null) {
    // Obtener solo los productos asignados a la tanda
    rows = await db.rawQuery('''
      SELECT p.*
      FROM productos p
      INNER JOIN productos_tanda pt ON pt.productoId = p.id
      WHERE pt.tandaId = ?
      ORDER BY p.nombre ASC
    ''', [tandaId]);
  } else {
    // Obtener todos los productos
    rows = await db.query('productos', orderBy: 'nombre ASC');
  }

  return rows.map((m) => Producto.fromMap(m)).toList();
}


  // ================== PEDIDOS ==================
  static Future<int> insertarPedidoConDetalles(Pedido pedido) async {
    final db = await _getDatabase();
    final pedidoId = await db.insert('pedidos', {
      'tandaId': pedido.tandaId,
      'cliente': pedido.cliente,
      'direccion': pedido.direccion,
      'entregado': pedido.entregado ? 1 : 0,
      'pagado': pedido.pagado ? 1 : 0,
      'pagoParcial': pedido.pagoParcial,
    });

    for (final detalle in pedido.detalles) {
      await db.insert('detalles_pedido', {
        'pedidoId': pedidoId,
        'productoId': detalle.producto.id!,
        'cantidad': detalle.cantidad,
      });

      final stockActual =
          await obtenerStockProducto(pedido.tandaId, detalle.producto.id!);
      final nuevoStock = stockActual - detalle.cantidad;
      await actualizarStockProducto(
          pedido.tandaId, detalle.producto.id!, nuevoStock);
    }

    return pedidoId;
  }

  static Future<void> actualizarPedidoConDetalles(Pedido pedido) async {
    final db = await _getDatabase();

    // Restaurar stock de detalles antiguos
    final antiguos = await db.query('detalles_pedido',
        where: 'pedidoId = ?', whereArgs: [pedido.id!]);
    for (final d in antiguos) {
      final productoId = d['productoId'] as int;
      final cantidad = d['cantidad'] as int;
      final stockActual =
          await obtenerStockProducto(pedido.tandaId, productoId);
      await actualizarStockProducto(
          pedido.tandaId, productoId, stockActual + cantidad);
    }

    // Actualizar pedido
    await db.update(
      'pedidos',
      {
        'tandaId': pedido.tandaId,
        'cliente': pedido.cliente,
        'direccion': pedido.direccion,
        'entregado': pedido.entregado ? 1 : 0,
        'pagado': pedido.pagado ? 1 : 0,
        'pagoParcial': pedido.pagoParcial,
      },
      where: 'id = ?',
      whereArgs: [pedido.id!],
    );

    // Borrar detalles antiguos
    await db.delete('detalles_pedido', where: 'pedidoId = ?', whereArgs: [pedido.id!]);

    // Insertar nuevos detalles y descontar stock
    for (final detalle in pedido.detalles) {
      await db.insert('detalles_pedido', {
        'pedidoId': pedido.id!,
        'productoId': detalle.producto.id!,
        'cantidad': detalle.cantidad,
      });

      final stockActual =
          await obtenerStockProducto(pedido.tandaId, detalle.producto.id!);
      await actualizarStockProducto(
          pedido.tandaId, detalle.producto.id!, stockActual - detalle.cantidad);
    }
  }

  static Future<List<Pedido>> obtenerPedidos({int? tandaId}) async {
    final db = await _getDatabase();
    final rows = await db.query(
      'pedidos',
      where: tandaId != null ? 'tandaId = ?' : null,
      whereArgs: tandaId != null ? [tandaId] : null,
      orderBy: 'id DESC',
    );

    List<Pedido> pedidos = [];
    for (final pedidoMap in rows) {
      final pedidoId = pedidoMap['id'] as int;
      final detallesMap =
          await db.query('detalles_pedido', where: 'pedidoId = ?', whereArgs: [pedidoId]);

      final detalles = <DetallePedido>[];
      for (final d in detallesMap) {
        final prodMap =
            (await db.query('productos', where: 'id = ?', whereArgs: [d['productoId']])).first;
        detalles.add(DetallePedido(
          producto: Producto.fromMap(prodMap),
          cantidad: (d['cantidad'] as num).toInt(),
        ));
      }

      pedidos.add(Pedido(
        id: pedidoId,
        tandaId: (pedidoMap['tandaId'] as int?) ?? 0,
        cliente: pedidoMap['cliente'] as String,
        direccion: pedidoMap['direccion'] as String,
        entregado: ((pedidoMap['entregado'] ?? 0) as int) == 1,
        pagado: ((pedidoMap['pagado'] ?? 0) as int) == 1,
        pagoParcial: (pedidoMap['pagoParcial'] as num?)?.toDouble() ?? 0.0,
        detalles: detalles,
      ));
    }
    return pedidos;
  }
  static Future<void> insertarPedido(int tandaId, List<DetallePedido> detalles) async {
  final db = await _getDatabase();

  // Insertar el pedido en la tabla `pedidos`
  final pedidoId = await db.insert(
    'pedidos',
    {
      'tanda_id': tandaId,
      'fecha': DateTime.now().toIso8601String(),
    },
  );

  // Insertar detalles en la tabla `detalles_pedido`
  for (var detalle in detalles) {
    await db.insert(
      'detalles_pedido',
      {
        'pedido_id': pedidoId,
        'producto_id': detalle.producto.id,
        'cantidad': detalle.cantidad,
      },
    );
  }
}

  static Future<void> eliminarPedidoPorId(int id) async {
    final db = await _getDatabase();

    final detalles = await db.query('detalles_pedido', where: 'pedidoId = ?', whereArgs: [id]);
    if (detalles.isNotEmpty) {
      final pedido = await db.query('pedidos', where: 'id = ?', whereArgs: [id]);
      final tandaId = pedido.first['tandaId'] as int;
      for (final d in detalles) {
        final productoId = d['productoId'] as int;
        final cantidad = d['cantidad'] as int;
        final stockActual = await obtenerStockProducto(tandaId, productoId);
        await actualizarStockProducto(tandaId, productoId, stockActual + cantidad);
      }
    }

    await db.delete('detalles_pedido', where: 'pedidoId = ?', whereArgs: [id]);
    await db.delete('pedidos', where: 'id = ?', whereArgs: [id]);
  }

  // ================== GASTOS ==================
  static Future<int> insertarGasto(Gasto gasto) async {
    final db = await _getDatabase();
    return await db.insert('gastos', {
      'tandaId': gasto.tandaId!,
      'descripcion': gasto.descripcion,
      'monto': gasto.monto,
      'fecha': gasto.fecha.toIso8601String(),
    });
  }
  
  
  static Future<void> eliminarGastoPorId(int id) async {
    final db = await _getDatabase();
    await db.delete('gastos', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> actualizarGasto(Gasto gasto) async {
    final db = await _getDatabase();
    await db.update(
      'gastos',
      gasto.toMap(),
      where: 'id = ?',
      whereArgs: [gasto.id!],
    );
  }

  static Future<List<Gasto>> obtenerGastos({int? tandaId}) async {
    final db = await _getDatabase();
    final rows = await db.query(
      'gastos',
      where: tandaId != null ? 'tandaId = ?' : null,
      whereArgs: tandaId != null ? [tandaId] : null,
      orderBy: 'fecha DESC',
    );
    return rows.map((m) => Gasto.fromMap(m)).toList();
  }

  // ================== TANDAS ==================
  static Future<int> insertarTanda(Tanda tanda) async {
    final db = await _getDatabase();
    return await db.insert('tandas', {'nombre': tanda.nombre});
  }

  static Future<void> actualizarTanda(Tanda tanda) async {
    final db = await _getDatabase();
    await db.update(
      'tandas',
      {'nombre': tanda.nombre},
      where: 'id = ?',
      whereArgs: [tanda.id!],
    );
  }

  static Future<void> eliminarTanda(int id) async {
    final db = await _getDatabase();
    final pedidos = await db.query('pedidos', where: 'tandaId = ?', whereArgs: [id]);
    for (final p in pedidos) {
      await eliminarPedidoPorId(p['id'] as int);
    }
    await db.delete('gastos', where: 'tandaId = ?', whereArgs: [id]);
    await db.delete('tandas', where: 'id = ?', whereArgs: [id]);
    await db.delete('productos_tanda', where: 'tandaId = ?', whereArgs: [id]);
  }

  // ================== PRODUCTOS_TANDA ==================
  static Future<int> asignarProductoATanda(int tandaId, int productoId, {int stock = 0}) async {
    final db = await _getDatabase();
    return await db.insert(
      'productos_tanda',
      {
        'tandaId': tandaId,
        'productoId': productoId,
        'stock': stock,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  static Future<void> limpiarProductosDeTanda(int tandaId) async {
    final db = await _getDatabase();
    await db.delete('productos_tanda', where: 'tandaId = ?', whereArgs: [tandaId]);
  }

  static Future<List<Map<String, dynamic>>> obtenerProductosDeTanda(int tandaId) async {
    final db = await _getDatabase();
    final rows = await db.rawQuery('''
      SELECT pt.id, pt.stock, p.id as productoId, p.nombre, p.precio
      FROM productos_tanda pt
      INNER JOIN productos p ON p.id = pt.productoId
      WHERE pt.tandaId = ?
    ''', [tandaId]);
    return rows;
  }

  static Future<int> obtenerStockProducto(int tandaId, int productoId) async {
    final db = await _getDatabase();
    final result = await db.query(
      'productos_tanda',
      columns: ['stock'],
      where: 'tandaId = ? AND productoId = ?',
      whereArgs: [tandaId, productoId],
    );

    if (result.isNotEmpty) {
      return result.first['stock'] as int;
    }
    return 0;
  }

  static Future<void> actualizarStockProducto(int tandaId, int productoId, int nuevoStock) async {
    final db = await _getDatabase();
    await db.update(
      'productos_tanda',
      {'stock': nuevoStock},
      where: 'tandaId = ? AND productoId = ?',
      whereArgs: [tandaId, productoId],
    );
  }

  // ================== INFORMES ==================
  static Future<List<Map<String, dynamic>>> obtenerIngresosAgrupadosPorTanda(int tandaId) async {
    final db = await _getDatabase();
    final result = await db.rawQuery('''
      SELECT p.id AS pedidoId, SUM(dp.cantidad * pr.precio) AS ingreso
      FROM pedidos p
      INNER JOIN detalles_pedido dp ON p.id = dp.pedidoId
      INNER JOIN productos pr ON dp.productoId = pr.id
      WHERE p.tandaId = ?
      GROUP BY p.id
    ''', [tandaId]);
    return result;
  }
  static Future<List<Map<String, dynamic>>> obtenerIngresosPorProducto(int tandaId) async {
  final db = await _getDatabase();

  // Obtener detalles de pedidos
  final result = await db.rawQuery('''
    SELECT pr.id AS productoId, pr.nombre AS producto, pr.precio,
           SUM(dp.cantidad) AS cantidadTotal,
           SUM(dp.cantidad * pr.precio) AS ingresoTotal
    FROM pedidos p
    INNER JOIN detalles_pedido dp ON p.id = dp.pedidoId
    INNER JOIN productos pr ON dp.productoId = pr.id
    WHERE p.tandaId = ?
    GROUP BY pr.id
  ''', [tandaId]);

  return result;
}

  static Future<double> obtenerTotalPagosParcialesPorTanda(int tandaId) async {
  final db = await _getDatabase();
  final result = await db.rawQuery('''
    SELECT SUM(pagoParcial) AS totalPagos
    FROM pedidos
    WHERE tandaId = ?
  ''', [tandaId]);

  if (result.isNotEmpty && result.first['totalPagos'] != null) {
    return (result.first['totalPagos'] as num).toDouble();
  }
  return 0.0;
}

  static Future<double> obtenerTotalIngresosPorTanda(int tandaId) async {
    final db = await _getDatabase();
    final result = await db.rawQuery('''
      SELECT SUM(dp.cantidad * pr.precio) AS totalIngresos
      FROM pedidos p
      INNER JOIN detalles_pedido dp ON p.id = dp.pedidoId
      INNER JOIN productos pr ON dp.productoId = pr.id
      WHERE p.tandaId = ?
    ''', [tandaId]);

    if (result.isNotEmpty && result.first['totalIngresos'] != null) {
      return (result.first['totalIngresos'] as num).toDouble();
    }
    return 0.0;
  }

  static Future<List<Gasto>> obtenerGastosPorTanda(int tandaId) async {
    final db = await _getDatabase();
    final rows = await db.query(
      'gastos',
      where: 'tandaId = ?',
      whereArgs: [tandaId],
      orderBy: 'fecha DESC',
    );
    return rows.map((m) => Gasto.fromMap(m)).toList();
  }

  static Future<double> obtenerTotalGastosPorTanda(int tandaId) async {
    final db = await _getDatabase();
    final result = await db.rawQuery('''
      SELECT SUM(monto) AS totalGastos
      FROM gastos
      WHERE tandaId = ?
    ''', [tandaId]);

    if (result.isNotEmpty && result.first['totalGastos'] != null) {
      return (result.first['totalGastos'] as num).toDouble();
    }
    return 0.0;
  }

  // ================== CLIENTES DEUDORES ==================
  static Future<List<String>> obtenerClientesDeudores() async {
    final db = await _getDatabase();
    final result = await db.rawQuery('''
      SELECT DISTINCT cliente
      FROM pedidos
      WHERE pagado = 0
    ''');
    return result.map((row) => row['cliente'] as String).toList();
  }

  static Future<List<Pedido>> obtenerPedidosNoPagadosPorCliente(String cliente) async {
  final db = await _getDatabase();
  final pedidosMap = await db.query(
    'pedidos',
    where: 'cliente = ? AND pagado = 0',
    whereArgs: [cliente],
    orderBy: 'id DESC',
  );

  List<Pedido> pedidos = [];
  for (final pedidoMap in pedidosMap) {
    final pedidoId = pedidoMap['id'] as int;
    final detallesMap = await db.query('detalles_pedido', where: 'pedidoId = ?', whereArgs: [pedidoId]);

    final detalles = <DetallePedido>[];
    for (final d in detallesMap) {
      final prodMap = (await db.query('productos', where: 'id = ?', whereArgs: [d['productoId']])).first;
      detalles.add(DetallePedido(
        producto: Producto.fromMap(prodMap),
        cantidad: (d['cantidad'] as num).toInt(),
      ));
    }

    // Obtener el nombre de la tanda
    String nombreTanda = '';
    if (pedidoMap['tandaId'] != null) {
      final tandaMap = (await db.query(
        'tandas',
        where: 'id = ?',
        whereArgs: [pedidoMap['tandaId'] as int],
      )).first;
      nombreTanda = tandaMap['nombre'] as String;
    }

    pedidos.add(Pedido(
      id: pedidoId,
      tandaId: (pedidoMap['tandaId'] as int?) ?? 0,
      cliente: pedidoMap['cliente'] as String,
      direccion: pedidoMap['direccion'] as String,
      entregado: ((pedidoMap['entregado'] ?? 0) as int) == 1,
      pagado: ((pedidoMap['pagado'] ?? 0) as int) == 1,
      pagoParcial: (pedidoMap['pagoParcial'] as num?)?.toDouble() ?? 0.0,
      detalles: detalles,
      nombreTanda: nombreTanda, // <-- agregamos el nombre de la tanda
    ));
  }

  return pedidos;
}


static Future<void> liquidarCliente(String cliente) async {
  final db = await _getDatabase();
  final nombreNormalizado = cliente.toLowerCase().trim();

  // Obtener todos los pedidos no pagados
  final pedidos = await db.query(
    'pedidos',
    where: 'LOWER(cliente) = ? AND pagado = 0',
    whereArgs: [nombreNormalizado],
  );

  for (final pedido in pedidos) {
    final pedidoId = pedido['id'] as int;

    // Calcular total del pedido desde detalles
    final detalles = await db.query(
      'detalles_pedido',
      where: 'pedidoId = ?',
      whereArgs: [pedidoId],
    );

    double total = 0.0;
    for (final d in detalles) {
      final productoId = d['productoId'] as int;
      final cantidad = d['cantidad'] as int;

      final producto = await db.query(
        'productos',
        where: 'id = ?',
        whereArgs: [productoId],
      );

      if (producto.isNotEmpty) {
        final precio = (producto.first['precio'] as num).toDouble();
        total += precio * cantidad;
      }
    }

    // Actualizar pedido: pagado = 1 y pagoParcial = total
    await db.update(
      'pedidos',
      {'pagado': 1, 'pagoParcial': total},
      where: 'id = ?',
      whereArgs: [pedidoId],
    );
  }

  print("Pedidos liquidados: ${pedidos.length}");
}



  static Future<List<Map<String, dynamic>>> obtenerTandasConConteo() async {
    final db = await _getDatabase();
    final result = await db.rawQuery('''
      SELECT t.id, t.nombre,
             (SELECT COUNT(*) FROM pedidos p WHERE p.tandaId = t.id) AS pedidosCount
      FROM tandas t
      ORDER BY t.id DESC
    ''');
    return result;
  }

// ================== INSUMOS ==================
static Future<int> insertarInsumo(Insumo insumo) async {
  final db = await _getDatabase();
  return await db.insert('insumos', insumo.toMap());
}

static Future<List<Insumo>> getInsumos() async {
  final db = await _getDatabase();
  final List<Map<String, dynamic>> maps = await db.query('insumos');
  return maps.map((map) => Insumo.fromMap(map)).toList();
}

// Relacionar insumo con un producto
static Future<int> addInsumoToProducto(int productoId, int insumoId, double cantidad) async {
  final db = await _getDatabase();
  return await db.insert('producto_insumo', {
    'producto_id': productoId,
    'insumo_id': insumoId,
    'cantidad': cantidad,
  });
}

// Obtener insumos de un producto
static Future<List<Map<String, dynamic>>> obtenerInsumosDeProducto(int productoId) async {
  final db = await _getDatabase();
  return await db.rawQuery('''
    SELECT i.id, i.nombre, pi.cantidad, i.unidad
    FROM producto_insumo pi
    JOIN insumos i ON pi.insumo_id = i.id
    WHERE pi.producto_id = ?
  ''', [productoId]);
}

// Eliminar relación producto-insumo
static Future<int> eliminarProductoInsumo(int productoId, int insumoId) async {
  final db = await _getDatabase();
  return await db.delete(
    'producto_insumo',
    where: 'producto_id = ? AND insumo_id = ?',
    whereArgs: [productoId, insumoId],
  );
}

// Actualizar cantidad de un insumo en un producto
static Future<int> actualizarCantidadInsumo(int productoId, int insumoId, double nuevaCantidad) async {
  final db = await _getDatabase();
  return await db.update(
    'producto_insumo',
    {'cantidad': nuevaCantidad},
    where: 'producto_id = ? AND insumo_id = ?',
    whereArgs: [productoId, insumoId],
  );
}

// Insertar factura
static Future<int> insertarFactura(int productoId, String nombre, String path) async {
  final db = await _getDatabase();
  return await db.insert('facturas', {
    'productoId': productoId, // <- coincide con la tabla
    'nombre': nombre,
    'path': path,
  });
}


// Obtener facturas de un producto
static Future<List<Map<String, dynamic>>> obtenerFacturasDeProducto(int productoId) async {
  final db = await _getDatabase();
  return await db.query(
    'facturas',
    where: 'productoId = ?', // <- CORREGIDO
    whereArgs: [productoId],
  );
}

// Eliminar factura
static Future<int> eliminarFactura(int id) async {
  final db = await _getDatabase();
  return await db.delete(
    'facturas',
    where: 'id = ?',
    whereArgs: [id],
  );
}

// Actualizar nombre de factura
static Future<int> actualizarNombreFactura(int id, String nuevoNombre) async {
  final db = await _getDatabase();
  return await db.update(
    'facturas',
    {'nombre': nuevoNombre},
    where: 'id = ?',
    whereArgs: [id],
  );
}


}




